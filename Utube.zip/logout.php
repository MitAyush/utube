<?php 

	require_once "includes/config.php";
	unset($_COOKIE['userloggedin']);
	setcookie('userloggedin', null, -1);
	session_destroy();
	header('Location: index.php');
 ?>