 <?php 
 	require 'includes/config.php';
	require 'includes/classes/formsantizer.php';
	require 'includes/classes/validation.php';

	if (isset($_SESSION['userloggedin'])) {
		header("Location:index.php");
	}

	if (isset($_POST['signupsubmit'])) {
		$formsantizer = new formsantizer();

		$firstname = $formsantizer->srtingsantinize($_POST["firstname"], 1);
		$lastname = $formsantizer->srtingsantinize($_POST["lastname"], 1);
		$username = $formsantizer->srtingsantinize($_POST["username"], 0);
		$email = $formsantizer->srtingsantinize($_POST["email"], 0);
		$password = $formsantizer->passwordsantinize($_POST["password"]);

	}elseif (isset($_POST['loginsubmit'])) {
		$formsantizer = new formsantizer();

		//$username = $formsantizer->srtingsantinize($_POST["username"], 0);
		$loginemail = $formsantizer->srtingsantinize($_POST["loginemail"], 0);
		$loginpassword = $formsantizer->passwordsantinize($_POST["loginpassword"]);

		/*============check gamil and password====================*/
			$loginpassword = hash('md5', $loginpassword);
			$loginpassword = hash('md5', $loginpassword);

			$loginpassword .="vko5m5m5m5skls";

			$query = $con->prepare("SELECT * from users where email = :loginemail and password = :loginpassword");
			$query->bindParam(":loginemail", $loginemail);
			$query->bindParam(":loginpassword", $loginpassword);
			$query->execute();

			$sqldata = $query->fetch(PDO::FETCH_ASSOC);
			if ($query->rowCount()) {
				$expiry = time() + (60*60);
				setcookie('userloggedin', $sqldata['username'], $expiry);
				$_SESSION['userloggedin'] = $sqldata['username'];
				header("location:index.php");
			}
			else{
				$invaliduser = "Username and Password doesn't match.";
			}
	}


  ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Signup</title>
 	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="includes/css/demo.css">

	<script src="https://kit.fontawesome.com/92affb5439.js" crossorigin="anonymous"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

	<script type="text/javascript" src="includes/js/signup-login.js"></script>

 </head>
 <body>
 	<div class="signup-login">
 		<br>
 		<br>
 		<div class="signupclass">
 			<div class="row justify-content-center">
				<div class="col-md-6">
				<div class="card">
				<header class="card-header">
					<h4 class="card-title mt-2">Sign up</h4>
				</header>
				<article class="card-body">
				<form action="" method="POST">
					<div class="form-row">
						<div class="col form-group">
							<label for="firstname">First name </label>   
						  	<input type="text" class="form-control" value="<?php if (isset($_POST['signupsubmit']))echo $firstname; ?>" name="firstname" id="firstname" placeholder="" autocomplete="off" required>
						  	<small class="form-text fncls hideit" style="color:red;">First name must be between 3 and 15.</small>
						</div> <!-- form-group end.// -->
						<div class="col form-group">
							<label for="lastname">Last name</label>
						  	<input type="text" class="form-control" value="<?php if (isset($_POST['signupsubmit']))echo $lastname; ?>" id="lastname" name="lastname" placeholder="" autocomplete="off" required>
						  	<small class="form-text lncls hideit" style="color:red;">Last name must be between 3 and 15.</small>
						</div> <!-- form-group end.// -->
					</div> <!-- form-row end.// -->
					<div class="form-group">
						<label for="email">Email address</label>
						<input type="email" class="form-control" value="<?php if (isset($_POST['signupsubmit']))echo $email; ?>" name="email" id="email" autocomplete="off" >
						<small class="form-text emcls hideit" style="color:red;">Email address is not valid.</small>
						<small class="form-text emtaken hideit" style="color:red;">Email address has already taken.</small>
					</div> <!-- form-group end.// -->

					<div class="form-group">
						<label for="username">Username</label>
						<input type="text" class="form-control" value="<?php if (isset($_POST['signupsubmit']))echo $username; ?>" name="username"  id="username" autocomplete="off" required>
						<small class="form-text uncls hideit" style="color:red;">Username must be between 3 and 25.</small>
						<small class="form-text untaken hideit" style="color:red;">Username is alerady taken.</small>
					</div> <!-- form-group end.// -->

					<!-- <div class="form-group">
							<label class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="gender" value="option1">
						  <span class="form-check-label"> Male </span>
						</label>
						<label class="form-check form-check-inline">
						  <input class="form-check-input" type="radio" name="gender" value="option2">
						  <span class="form-check-label"> Female</span>
						</label>
					</div> --> <!-- form-group end.// -->
					<div class="form-group">
						<label for="password">Create password</label>
					    <input class="form-control" type="password" name="password" id="password" required>
					    <small class="form-text  pwd hideit" style="color:red;">Password must be between 8 and 25.</small>
					</div> <!-- form-group end.// -->  
				    <div class="form-group">
				        <button type="submit" name="signupsubmit" class="btn btn-primary btn-block"> Register  </button>
				    </div> <!-- form-group// -->                                              
				</form>
				</article> <!-- card-body end .// -->
				<div class="border-top card-body text-center">Have an account? <a href="#" id="gologin">Log In</a></div>
				</div> <!-- card.// -->
				</div> <!-- col.//-->

				</div> <!-- row.//-->
 		</div>
<!-- --------------------------Login form--------------------------->
 		<div class="login">
 			<br>
 			<br>
 			<div class="row justify-content-center">
				<div class="col-md-6">
					<div class="card">
					<header class="card-header">
						<h4 class="card-title mt-2">Login</h4>
					</header>
					<article class="card-body">
					<form action="" method="POST">
						
						<div class="form-group">
							<label for="signinemail">Email address</label>
							<input type="email" class="form-control" value="<?php if (isset($_POST['loginsubmit']))echo $loginemail; ?>" name="loginemail" id="signinemail" placeholder="" required>

							<small class="form-text" style="color: red;">
								<?php if (isset($_POST['loginsubmit'])) {
									echo $invaliduser;
								} ?>
							</small>
						</div> <!-- form-group end.// -->
						
						<div class="form-group">
							<label for="signinpassword">Password</label>
						    <input class="form-control" type="password" name="loginpassword" id="signinpassword" required>
						</div> <!-- form-group end.// -->  
					    <div class="form-group">
					        <button type="submit" name="loginsubmit" class="btn btn-primary btn-block"> Login  </button>
					    </div> <!-- form-group// -->      
					                                             
					</form>
					</article> <!-- card-body end .// -->
					<div class="border-top card-body text-center">Need an account? <a href="#" id="gosignup">Sign up</a></div>
					</div> <!-- card.// -->
				</div> <!-- col.//-->

				</div>
 		</div>
 	</div>
<?php //if user is already loggedin
	
	
	if (isset($_POST["signupsubmit"])){
		?>
		<script>
			var loginclass = document.getElementsByClassName('login');
			var signupclass = document.getElementsByClassName('signupclass');
			$(loginclass).hide();
			$(signupclass).show();
		</script>
		<?php
		/*===================================validation========================*/
		$validate = new validation();
		$isvalidfirstname = $validate->validatefirstname($firstname);
		if (!$isvalidfirstname) {
			echo "<script>
				$('.fncls').removeClass('hideit');
			</script>";	
		}		

		$isvalidlastname = $validate->validatelastname($lastname);
		if (!$isvalidlastname) {
			echo "<script>
				$('.lncls').removeClass('hideit');
			</script>";	
		}

		$isvalidusername = $validate->validateusername($username);
		if (!$isvalidusername) {
			echo "<script>
				$('.uncls').removeClass('hideit');
			</script>";	
		}

		$usernametaken = $validate->usernametaken($username, $con);
		if ($usernametaken) {
			/*echo "<script>
				$('.untaken').removeClass('hideit');
			</script>";	*/
		}

		$isvalidemail = $validate->validateemail($email);
		if (!$isvalidemail) {
			echo "<script>
				$('.uncls').removeClass('hideit');
			</script>";	
		}
		$emailtaken = $validate->emailtaken($email, $con);
		if ($emailtaken) {
			echo "<script>
				$('.emtaken').removeClass('hideit');
			</script>";	
		}

		$isvalidpassword = $validate->validatepassword($password);
		if (!$isvalidpassword) {
			echo "<script>
				$('.pwd').removeClass('hideit');
			</script>";	
		}
		/*=============Register the data=====================*/
		if ($isvalidpassword && (!$emailtaken) && $isvalidemail && (!$usernametaken) && $isvalidusername && $isvalidlastname && $isvalidfirstname) {
			$password = hash('md5', $password);
			$password = hash('md5', $password);

			$password .= "vko5m5m5m5skls";
			
			$query = $con->prepare("INSERT into users (firstname, lastname, email, username, password, profilepic) values(:firstname, :lastname, :email,:username ,:password, :profilepic)");
			$profilepic = 'includes/images/profilepic/default.jpg';
			
			$query->bindParam(":firstname", $firstname);
			$query->bindParam(":lastname", $lastname);
			$query->bindParam(":username", $username);
			$query->bindParam(":email", $email);
			$query->bindParam(":password", $password);
			$query->bindParam(":profilepic", $profilepic);
			if($query->execute()){
				echo "";
			}
			else{
				echo "Data insertion fail";
				return false;
			}
		}

	}
	elseif (!isset($_POST["loginsubmit"])) {
		echo "<script>
				var loginclass = document.getElementsByClassName('login');
				var signupclass = document.getElementsByClassName('signupclass');
				$(signupclass).hide();
				$(loginclass).show();
			</script>";
			
	}

 ?>
</body>
 </html>