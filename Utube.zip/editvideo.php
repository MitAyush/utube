<!DOCTYPE html>
<html>
<head>
	<title>Edit Video</title>
</head>
<body>

<?php 
	require 'includes/header.php';
	echo "<br><br><br>";

	if (!isset($_GET['videoid'])) {
		echo "No video to edit";
		exit();
	}

	$videoid = $_GET['videoid'];
	if (!$userloggedinobj->isUploadedBy($videoid)) {
		echo "You are not allowed to edit this video";
		exit();
	}
	require 'includes/classes/videoplayer.php';
	require 'includes/classes/video.php';
	require 'includes/classes/editvideoProvider.php';

	if (isset($_POST['update'])) {
		$title = $_POST["title"];
		$title = strip_tags($title); // strip html tags
		$title = str_replace("  ", "", $title);
		$title = ucfirst($title);


		$description = $_POST["description"];
		$description = strip_tags($description); // strip html tags
		$description = str_replace("  ", "", $description);
		$description = ucfirst($description);

		$privacy = $_POST['privacyinput'];
		$category = $_POST['category'];

		$query = $con->prepare("UPDATE videos set title = :title, description = :description
								, category = :category, privacy = :privacy where id = :id");
		$query->bindParam(":title", $title);
		$query->bindParam(":description", $description);
		$query->bindParam(":category", $category);
		$query->bindParam(":privacy", $privacy);
		$query->bindParam(":id", $videoid);
		$query->execute();


	}

	$videoobj = new video($con, $videoid, $userloggedinobj);
	$videoplayer = new videoplayer($videoobj);
	

	
	
?>


	<div id="edit-video-left">
		<?php echo $videoplayer->createvideoplayer(false); ?>
		<br><br>
		<div>
			<?php 
				$description = $videoobj->getdescription();

				$editvideo = new EditVideo($con, $videoobj);
				echo $editvideo->createForm();
			 ?>
		</div>
	</div>

	<div id="screensorts">
		<?php echo $editvideo->getScreenshorts($videoid); ?>
	</div>

</body>
</html>

<script>
	$(document).ready(function(){
		var description = <?php echo json_encode($description); ?>;
		$('textarea#exampleFormControlTextarea1').val(description);
	});
</script>




















