<!DOCTYPE html>
<html>
<head>
	<title>Liked Video</title>
</head>
<style>
	.test{
		float: left;
   		width: 100%;
	}
</style>
<body>
	<?php 
		require 'includes/header.php';

		if (!isset($_SESSION['userloggedin'])) {
			header("Location:signin.php");
		}
		require_once 'includes/classes/likeVideoProvider.php';
	 ?>
	<div class="mainsection">
		<div class="maincontent">
			<?php 

				$likedVideoArray = $userloggedinobj->getLikedVideoArray();

				$likedVideo = new LikeVideoProvider($con, $likedVideoArray);
				echo $likedVideo->createLikedVideo();
				
			 ?>
		</div>
	</div>
</body>
</html>