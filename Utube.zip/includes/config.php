<?php 
	ob_start();
	date_default_timezone_set("Asia/Kolkata");
	try{
		$con = new PDO("mysql:dbname=utube;host=localhost", "root", "");
		$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
		session_start();
	}
	catch(PDOException $e){
		echo "Conncetion fail".$e->getMessage();
	}

 ?>