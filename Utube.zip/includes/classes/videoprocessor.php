<?php 
 /**
  * 
  */
 class videoprocessor
 {
 	private $con, $sizelimit = 524288000;	 //524288000 Bytes == 500 MB
 	private $videotypes = array("mp4", "flv", "mkv", "vob", "ogg", "avi", "mov", "mpeg");
 	private $ffmpegpath, $ffprobepath;
 	function __construct($con)
 	{
 		$this->ffmpegpath = realpath("includes/ffmpeg/bin/ffmpeg.exe");
 		$this->ffprobepath = realpath("includes/ffmpeg/bin/ffprobe.exe");
 		$this->con = $con;
 	}

 	public function upload($videouploaddata){
 		$targetdir = "uploads/videos/";
 		$videodata = $videouploaddata->videodetailarray;

 		$tempfilepath = $targetdir.uniqid().basename($videodata["name"]);
 		//$tempfilepath = uploads/videos/uniqidWWE match.flv

 		$tempfilepath = str_replace(" ", "_", $tempfilepath);
 		$isvaliddata = $this->checkvideodata($videodata, $tempfilepath);
 		if (!$isvaliddata) {
 			return false;
 		}

 		// move uploaded file to folder
 		if (move_uploaded_file($videodata["tmp_name"], $tempfilepath)) {
 			$finalfilepath = $targetdir.uniqid().".mp4";

 			$insertedId = $this->insertvideodata($videouploaddata, $finalfilepath);

 			if (!$insertedId) {
 				echo "Insert query fails";
 				return false;
 			}
 		}

 		if (!$this->convertvideotomp4($tempfilepath, $finalfilepath)) {
 			echo "Convertion of video is fail";
 			return false;
 		}
 		if (!$this->deleteoriginalvideo($tempfilepath)) {
 			echo "Uploading fail";
 			return false;
 		}
 		if (!$this->generatethumbnails($finalfilepath)) {
 			//echo "Thumbnail generation is fail";
 			//return false;
 		}
 		return $insertedId;
 	}

 	private function checkvideodata($videodata, $filepath){
 		$videotype = pathInfo($filepath, PATHINFO_EXTENSION);
 		if (!$this->isvalidsize($videodata)) {
 			$datalimitinbytes = $this->sizelimit / 1048576;
 			echo "File size is larger than". $datalimitinbytes."btyes";
 			return false;
 		}
 		elseif(!$this->isvalidtype($videotype)){
 			echo "File type must be";
 			return false;
 		}
 		elseif ($this->hasothererror($videodata)) {
 			echo "Error code". $videodata["error"];
 			return false;
 		}
 		return true;
 	}


 	private function isvalidsize($videodata){
 		return $videodata["size"] <= $this->sizelimit;
 	}

 	private function isvalidtype($videotype){
 		$lowercase = strtolower($videotype);
 		return in_array($lowercase, $this->videotypes);
 	}

 	private function hasothererror($videodata){
 		return $videodata["error"] != 0;
 	}

 	private function insertvideodata($uploaddata, $filepath){
 		$query = $this->con->prepare("INSERT into videos(title, uploadedby, description, privacy, category, filepath) 
 			values(:title, :uploadedby, :description, :privacy, :category, :filepath)");
 		$query->bindParam(":title", $uploaddata->title);
 		$query->bindParam(":uploadedby", $uploaddata->uploadedby);
 		$query->bindParam(":description", $uploaddata->description);
 		$query->bindParam(":privacy", $uploaddata->privacy);
 		$query->bindParam(":category", $uploaddata->category);
 		$query->bindParam(":filepath", $filepath);

 		$query->execute();

 		return $this->con->lastInsertId();
 	}

 	private function convertvideotomp4($tempfilepath, $finalfilepath){
 		$cmd = $this->ffmpegpath." -i $tempfilepath $finalfilepath 2>&1";
 		$outputlog = array();
 		exec($cmd, $outputlog, $returnCode);
 		if ($returnCode) {
 			foreach ($outputlog as $line) {
 				echo $line."<br>";
 			}
 			return false;
 		}
 		return true;
 	}

 	private function deleteoriginalvideo($filepath){
 		if (!unlink($filepath)) {
 			echo "Original file can not deleted";
 			return false;
 		}
 		return true;
 	}

 	private function generatethumbnails($filepath){
 		$thumbnailsize = "253x142";
 		$numthumbnail = 3;
 		$pathtothumbnail = "uploads/videos/thumbnails";
 		$duration = $this->getduration($filepath);
 		$videoid =  $this->con->lastInsertId();
 		$this->updateduration($duration, $videoid);

 		for ($i=1; $i <= $numthumbnail; $i++) { 
 			$imgname = uniqid().".jpg";
 			$interval = rand($duration * 0.1, $duration*0.9);
 			$fullpath = "$pathtothumbnail/$videoid-$imgname";

 			$cmd = $this->ffmpegpath." -i $filepath -ss $interval -s $thumbnailsize -vframes 1 $fullpath 2>&1";
	 		$outputlog = array();
	 		exec($cmd, $outputlog, $returnCode);
	 		if ($returnCode) {
	 			foreach ($outputlog as $line) {
	 				echo $line."<br>";
	 			}
	 		}

	 		$query = $this->con->prepare("INSERT into thumbnails(videoid, filepath, selected) values(:videoid, :filepath, :selected)");
	 		$query->bindParam(":videoid", $videoid);
	 		$query->bindParam(":filepath", $fullpath);
	 		$query->bindParam(":selected", $selected);

	 		$selected = $i == 1 ? 1 : 0;
	 		if (!$query->execute()) {
	 			echo "Error inserting thumbnails \n";
	 			return false;
	 		}

 		}

 		return true;

 	}

 	private function getduration($filepath){
 		return (int)shell_exec("$this->ffprobepath -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 $filepath");
 	}

 	private function updateduration($duration, $videoid){
 		$hours = floor($duration / 3600);
 		$mins = floor(($duration - $hours*3600) / 60);
 		$secs = floor($duration % 60);

 		$hours = ($hours < 1) ? "" : $hours.":";
 		$mins = ($mins < 10) ? "0".$mins.":" : $mins.":";
 		$secs = ($secs < 10) ? "0".$secs : $secs;

 		$duration = $hours.$mins.$secs;

 		$query = $this->con->prepare("UPDATE videos set duration = :duration where id = :videoid");
 		$query->bindParam(":duration" , $duration);
 		$query->bindParam(":videoid" , $videoid);
 		$query->execute();
 	}











 }


 ?>