<?php 
	/**
	 * 
	 */
	class Search
	{
		private $con;
		function __construct($con)
		{
			$this->con = $con;
		}

		public function getResult(){
			$item = $_GET['search'];

			if (isset($_GET['orderBy'])) {
				$orderBy = $_GET['orderBy'];
			}
			else{
				$orderBy = 'views';
			}

			if (isset($_GET['type'])) {
				$type = $_GET['type'];
			}
			else{
				$type = 'desc';
			}
			/*============== condition for button classes ===================*/
			if ($orderBy == 'uploaddate' && $type == 'asc') {
				$oldest = 'btn btn-primary';
				$latest = '';
				$leastViewed = '';
				$mostViewed = '';
			}
			elseif ($orderBy == 'uploaddate') {
				$latest = 'btn btn-primary';
				$oldest = '';
				$leastViewed = '';
				$mostViewed = '';
			}
			else{
				$latest = '';
				$oldest = '';
				$leastViewed = '';
				$mostViewed = '';
			}

			if ($orderBy == 'views' && $type == 'asc'){
				$leastViewed = 'btn btn-primary';
				$mostViewed = '';
			}
			elseif ($orderBy == 'views' && $type == 'desc') {
				$leastViewed = '';
				$mostViewed = 'btn btn-primary';
			}
			

			$sendToSort = $item;

			$query = $this->con->prepare("SELECT * from videos where title like :item order by $orderBy $type limit 25");
			$item = "%".$item."%";
			$query->bindParam(":item", $item);
			$query->execute();
			$count = $query->rowCount();
			
			$htmldata = "<h6 class='search-found'>$count result found</h6>
						<span class='sort-by'>
							Sort By : &nbsp
							<span class='$oldest sort-btn' onclick='oldest(\"$sendToSort\", this)'>Oldest </span> ||
							<span class='$latest sort-btn' onclick='latest(\"$sendToSort\", this)'>Latest </span> ||
							<span class='$mostViewed sort-btn' onclick='mostViewed(\"$sendToSort\", this)'>Most Viewed</span> ||
							<span class='$leastViewed sort-btn' onclick='leastViewed(\"$sendToSort\", this)'>Least Viewed</span>
						</span>";

			while ($result = $query->fetch(PDO::FETCH_ASSOC)) {
				$thumbnails = $this->gethumbnail($result['id']);
				$title = $result['title'];
				$uploadedby = $result['uploadedby'];
				$views = $result['views'];
				$timeAgo = $this->time_elapsed_string($result['uploaddate']);
				$duration = $result['duration'];

				$htmldata .= "<div class='search-grid'>
								<div class='search-thumbnails'>
									$thumbnails
									<span class='search-duration-background'>
									<span class='search-duration'>$duration</span>
								</span>
								</div>
								
								<div class='search-info'>
									<span>$title </span> <br>
									<span><a href='profile.php?username=$uploadedby'>$uploadedby</a></span> <br>
									<span>$views  views &#8226 $timeAgo</span>
								</div>
							</div>";
			}

			
			return $htmldata;

		}


		private function gethumbnail($videoid){
			$query = $this->con->prepare("SELECT filepath from  thumbnails where videoid = :videoid and selected = 1");
			$query->bindParam(":videoid", $videoid);
			$query->execute();
			$result = $query->fetch(PDO::FETCH_ASSOC);
			$filepath = $result['filepath'];

			return "<a href='watch.php?id=$videoid'>
						<img src='$filepath'>
					</a>";		

		}

		private function time_elapsed_string($datetime, $full = false) {
		    $now = new DateTime;
		    $ago = new DateTime($datetime);
		    $diff = $now->diff($ago);

		    $diff->w = floor($diff->d / 7);
		    $diff->d -= $diff->w * 7;

		    $string = array(
		        'y' => 'year',
		        'm' => 'month',
		        'w' => 'week',
		        'd' => 'day',
		        'h' => 'hour',
		        'i' => 'minute',
		        's' => 'second',
		    );
		    foreach ($string as $k => &$v) {
		        if ($diff->$k) {
		            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
		        } else {
		            unset($string[$k]);
		        }
		    }

		    if (!$full) $string = array_slice($string, 0, 1);
		    return $string ? implode(', ', $string) . ' ago' : 'just now';
		}


	}


 ?>