<?php 
/**
 * 
 */
require_once 'buttonprovider.php';
class commentcontrol
{
	
	private $con, $userloggedinobj, $commentobj, $userloggedin;


	
	function __construct($con, $userloggedinobj, $commentobj, $userloggedin)
	{
		$this->con = $con;
		$this->userloggedinobj = $userloggedinobj;
		$this->commentobj = $commentobj;
		$this->userloggedin = $userloggedin;
	}

	public function createcontrols(){

		$likebutton = $this->createlikebutton();
		$dislikebutton = $this->createdislikebutton();
		$replybutton = $this->createreplybutton();
		$replysection = $this->createreplysection();
		$likecount = $this->createlikecount();

		return "<div class='controls'>
					$replybutton
					$likecount
					$likebutton
					$dislikebutton
				</div>
				$replysection";
	}

	public function createcontrolsWithoutReply(){

		$likebutton = $this->createlikebutton();
		$dislikebutton = $this->createdislikebutton();
		$replysection = $this->createreplysection();
		$likecount = $this->createlikecount();

		return "<div class='controls'>
					$likecount
					$likebutton
					$dislikebutton
				</div>
				$replysection";
	}


	private function createreplysection(){
		$postedby = $this->userloggedin;
		$videoid = $this->commentobj->getvideoid();
		$commentid = $this->commentobj->getcommentid();

		$profilebutton = buttonprovider::createuserbutton($this->con, $postedby);
		$cancelbuttonaction = "togelreply(this)";
		$cancelbutton = buttonprovider::createbutton("Cancel", null, $cancelbuttonaction, "cancelcomment");

		$postbuttonaction = "postreply(this, \"$postedby\", $videoid, $commentid, \"repliessection\")";
		$postbutton = buttonprovider::createbutton("Reply", null, $postbuttonaction, "postreply");

		return "<div class='commentform hideit'>
				$profilebutton
				<span class='commentarea'>
					<textarea class='mycomment' cols='55' placeholder='Add Public Comment...'></textarea>
				</span>
				$cancelbutton
				$postbutton
			</div>";	

	}

	private function createlikecount(){

		$numlikes = $this->commentobj->getnumlikes();
		return "<span class='likescount'>$numlikes</span>";

	}
	private function createreplybutton(){
		$text = "Reply";
		$action = "togglereply(this)";

		return buttonprovider::createbutton($text, null, $action, "justreply");
	}

	private function createlikebutton(){
		$commentid = $this->commentobj->getcommentid();
		$videoid = $this->commentobj->getvideoid();
		$action = ($this->userloggedin) ? "likecomment($commentid, this, $videoid)" : "showloginmessage()";

		if ($this->commentobj->waslikedby($this->userloggedin, $commentid)) {
			$imagesrc = "includes/images/alreadylike.png";
		}
		else{
			$imagesrc = "includes/images/like.png";
		}

		return buttonprovider::createbutton("", $imagesrc, $action, "likebutton");
	}

	private function createdislikebutton(){
		$videoid = $this->commentobj->getvideoid();
		$commentid = $this->commentobj->getcommentid();
		$action = ($this->userloggedin) ? "dislikecomment($commentid, this, $videoid)" : "showloginmessage()";
		
		if ($this->commentobj->wasdislikedby($this->userloggedin, $commentid)) {
			$imagesrc = "includes/images/alreadydislike.png";
		}
		else
			$imagesrc = "includes/images/dislike.png";

		return buttonprovider::createbutton("", $imagesrc, $action, "dislikebutton");
	}


}


 ?>