<?php 

	/**
	 * 
	 */
class buttonprovider
{
	
	public static function createbutton($text, $imagesrc, $action, $class)
	{
		$image = ($imagesrc == null) ? "" : "<img class='btnimage' src='$imagesrc'>";
		
		return "<button class='$class' onclick='$action'>
					 $image
					<span class='text'>$text</span>
				</button>";
	}

	public static function createuserbutton($con, $username){
		$userobj =  new user($con, $username);
		$imagesrc = $userobj->getprofilepic();

		return "<a href='profile.php?username=$username'>
					<img class='profilepic'src='$imagesrc'>
				</a>";

	}

	public static function createeditbutton($videoid){
		return "<div class='editbuttoncontainer'>
					<a href='editvideo.php?videoid=$videoid'>
						<button class='edit button'>
							<span class='editvideo'>Edit Video</span>
						</button>
					</a>
				</div>";
	}

	public static function createsubscribebutton($con, $usertoobj, $uploadedby, $userloggedin){



		$issubscribed = $usertoobj->issubscribedto($uploadedby, $userloggedin);
		$buttontext = $issubscribed ? "SUBSCRIBED" : "SUBSCRIBE";

		$buttontext .= " &nbsp ".$usertoobj->getsubscribercount($uploadedby);

		$buttonclass = $issubscribed ? "unsubscribe btn" : "subscribe btn";
		$action = "subscribe(\"$uploadedby\", \"$userloggedin\", this)";

		$button = buttonprovider::createbutton($buttontext, null, $action, $buttonclass);

		return "<div class='subscribebtn'>
					$button
				</div>";	
	}










	}


 ?>

