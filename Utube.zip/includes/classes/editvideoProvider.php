<?php 
	
/**
	 * 
	 */
class EditVideo
{
	private $con, $videoobj;
	function __construct($con, $videoobj){
		$this->con = $con;
		$this->videoobj = $videoobj;
	}
	
	public function createForm()
	{		
		$title = $this->videoobj->gettitle();
		$returnHtml = "<form method='post' action=''>
			  <div class='form-group'>
				<input class='form-control form-control-lg' value='$title' type='text' placeholder='Title' name='title' maxlength='70'>		
			  </div>
			  <div class='form-group'>
				<textarea class='form-control' id='exampleFormControlTextarea1' name='description'  placeholder='' rows='3' maxlength='1000'>
				</textarea>	
			  </div>";
	 	
		$returnHtml .= $this->getPrivacy();
		$returnHtml .= $this->getCategory();

		return $returnHtml."<button type='submit' name='update' class='btn btn-primary'>Submit</button>
						</form>";
		

		/*
			<div class='form-group'>
			    <select class='form-control' name='privacyinput'>
			      <option value='0'>Private</option>
			      <option value='1'>Public</option>
			    </select>
			  </div>

			  $query = $this->con->prepare("SELECT * FROM categories");
			$query->execute();
			$html .= '<div class="form-group">
					    <select class="form-control" name="category">';

			while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
			$html .= '<option value="'.$row['id'].'">'.$row['name'].'</option>';
		}

		$html .= '</select>
				  </div>
				  <button type="submit" name="update" class="btn btn-primary">Submit</button>
				</form>';
		return $html;
		*/
	}

	private function getCategory(){
		$query = $this->con->prepare("SELECT * FROM categories");
		$query->bindParam(":id", $id);
		$id = $this->videoobj->getvideoid();
		$query->execute();

		$category = $this->videoobj->getcategory();

		$returnHtml = "<div class='form-group'>
					    <select class='form-control' name='category'>";
		while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
			$id = $row['id'];
			$name = $row['name'];
			$selected = ($id == $category) ? "selected" : "";

			$returnHtml .= "<option value ='$id' $selected>$name</option> ";
		}

		$returnHtml .= "</select>
				  </div>";
		return $returnHtml;
	}

	private function getPrivacy(){
		if ($this->videoobj->getprivacy()) {
			return "<div class='form-group'>
			    <select class='form-control' name='privacyinput'>
			      <option value='0'>Private</option>
			      <option value='1' selected>Public</option>
			    </select>
			  </div>";
		}
		else{
			return "<div class='form-group'>
			    <select class='form-control' name='privacyinput'>
			      <option value='0' selected>Private</option>
			      <option value='1'>Public</option>
			    </select>
			  </div>";
		}

	}

	public function getScreenshorts($videoid){
		//	$videoid = number_format($videoid);
		$query = $this->con->prepare("SELECT * from thumbnails where videoid = :videoid");
		$query->bindParam(":videoid", $videoid);
		$query->execute();

		$returnHtml = "<div class='right-column'>";

		while($result = $query->fetch(PDO::FETCH_ASSOC)) {
			$filepath = $result['filepath'];
			$class = '';
			$id = $result['id'];
			if ($result['selected']) {
				$class = 'selected';
			}
			else
				$class = '';

			$returnHtml .= "<img src='$filepath']' class='$class' onclick=setSelected(this,$videoid,$id)>";
		}

		return $returnHtml .= "</div>";
	}


	}	

 ?>
