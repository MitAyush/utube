<?php 

	/**
	 * 
	 */
	class videouploaddata
	{
		public $videodetailarray, $title, $description, $privacy, $category, $uploadedby;
		
		function __construct($videodetailarray, $title, $description, $privacy, $category, $uploadedby)
		{
			$this->videodetailarray = $videodetailarray;
			$this->title = $title;
			$this->description = $description;
			$this->privacy = $privacy;
			$this->category = $category;
			$this->uploadedby = $uploadedby;
		}
	}


 ?>