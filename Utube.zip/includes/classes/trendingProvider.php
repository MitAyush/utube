<?php 
	/**
	 * 
	 */
	class TrendingPrpvider
	{
		private $con, $userToArray;
		function __construct($con)
		{
			$this->con = $con;
			$this->userToArray = $userToArray;
		}

		public function getTrendingVideo(){
			$query = $this->con->prepare("SELECT * from videos where uploaddate >= now() - INTERVAL 7 DAY order by views desc limit 15");
			$query->execute();
			
			$html = "<h5 class='sub-title' style='padding-top: 13px;'>Trending Videos</h5>";
			if (!$query->rowCount()) {
				return $html = "<h5 class='sub-title' style='padding-top: 60px;'>No Trending Videos to show</h5>";
			}
			

			while ($result = $query->fetch(PDO::FETCH_ASSOC)) {
				$thumbnails = $this->gethumbnail($result['id']);
				$uploadedby = $result['uploadedby'];
				$views = $result['views'];
				$title = $result['title'];
				$duration = $result['duration'];

				$timeAgo = $this->time_elapsed_string($result['uploaddate']);

				$html .= "<div class='subscription'>
							<div class='sub-thumb'>
								$thumbnails
							</div>
							<span class='sub-duration-background'>
								<span class='sub-duration'>$duration</span>
							</span>
							<div class='sub-info'>
								<span class='infogrid'>
									$title <br>
									<span class='gridviews'>
										<a href='profile.php?username=$uploadedby'>$uploadedby</a> <br>
										$views  views &#8226 $timeAgo
									</span>
								</span>
							</div>
						</div>";
			}
			
			return $html;

		}

		private function gethumbnail($videoid){
			$query = $this->con->prepare("SELECT filepath from  thumbnails where videoid = :videoid and selected = 1");
			$query->bindParam(":videoid", $videoid);
			$query->execute();
			$result = $query->fetch(PDO::FETCH_ASSOC);
			$filepath = $result['filepath'];

			return "<a href='watch.php?id=$videoid'>
						<img src='$filepath'>
					</a>";		

		}

		private function time_elapsed_string($datetime, $full = false) {
		    $now = new DateTime;
		    $ago = new DateTime($datetime);
		    $diff = $now->diff($ago);

		    $diff->w = floor($diff->d / 7);
		    $diff->d -= $diff->w * 7;

		    $string = array(
		        'y' => 'year',
		        'm' => 'month',
		        'w' => 'week',
		        'd' => 'day',
		        'h' => 'hour',
		        'i' => 'minute',
		        's' => 'second',
		    );
		    foreach ($string as $k => &$v) {
		        if ($diff->$k) {
		            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
		        } else {
		            unset($string[$k]);
		        }
		    }

		    if (!$full) $string = array_slice($string, 0, 1);
		    return $string ? implode(', ', $string) . ' ago' : 'just now';
		}

	}


 ?>