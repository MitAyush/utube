<?php 
	
	/**
	 * 
	 */
	class video
	{
		private $con, $sqldata, $userloggedinobj;
		function __construct($con, $input, $userloggedinobj)
		{
			$this->con = $con;
			$this->userloggedinobj = $userloggedinobj;


			if (is_array($input)) {
				$this->sqldata = $input;
			}
			else{
				$query = $this->con->prepare("SELECT * from videos where id = :input");
				$query->bindParam(":input", $input);
				$query->execute();
				if (!$query->rowCount()) {
					echo "<script>alert('No video found');</script>";
					exit();
				}
				$this->sqldata = $query->fetch(PDO::FETCH_ASSOC);
			}

			
		}


		public function getvideoid(){
			return $this->sqldata["id"];
		}

		public function getuploadedby(){
			return $this->sqldata["uploadedby"];
		}

		public function gettitle(){
			return $this->sqldata["title"];
		}

		public function getdescription(){
			return $this->sqldata["description"];
		}

		public function getprivacy(){
			return $this->sqldata["privacy"];
		}

		public function getfilepath(){
			return $this->sqldata["filepath"];
		}

		public function getcategory(){
			return $this->sqldata["category"];
		}

		

		public function getuploaddate(){
			$date = $this->sqldata["uploaddate"];
			return date("j M Y", strtotime($date));
		}

		public function getviews(){
			return $this->sqldata["views"];
		}

		public function getduration(){
			return $this->sqldata["duration"];
		}

		public function incrementview(){
			$query = $this->con->prepare("UPDATE  videos set views = views + 1 where id = :id");
			$query->bindParam(":id", $id);
			$id = $this->getvideoid();
			$query->execute();

			$this->sqldata["views"] += 1;
		}

	public function getlikes(){
		$query = $this->con->prepare("SELECT  count(*) as 'count' from likes where videoid = :videoid");
		$query->bindParam(":videoid", $videoid);
		$videoid = $this->getvideoid();
		$query->execute();
		$data = $query->fetch(PDO::FETCH_ASSOC);

		return $data['count'];

	}

	public function getdislikes(){
		$query = $this->con->prepare("SELECT  count(*) as 'count' from dislikes where videoid = :videoid");
		$query->bindParam(":videoid", $videoid);
		$videoid = $this->getvideoid();
		$query->execute();
		$data = $query->fetch(PDO::FETCH_ASSOC);

		return $data['count'];
	}
	
	public function waslikedby($userloggedin, $videoid){

		$query = $this->con->prepare("SELECT * from likes where username = :username and videoid = :videoid");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":videoid", $videoid);

		$query->execute();
		return $query->rowCount();
	}

	public function wasdislikedby($userloggedin, $videoid){

		$query = $this->con->prepare("SELECT * from dislikes where username = :username and videoid = :videoid");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":videoid", $videoid);

		$query->execute();
		return $query->rowCount();
	}

	public function getnumofcomments(){
		$query = $this->con->prepare("SELECT * from comments where videoid = :videoid");
		$query->bindParam(":videoid", $videoid);
		$videoid = $this->getvideoid();

		$query->execute();
		return $query->rowCount();
	}

	public function getallcomments(){
		$query = $this->con->prepare("SELECT * from comments where videoid = :videoid and responseto = 0 order by dateposted DESC");
		$query->bindParam(":videoid", $videoid);
		$videoid = $this->getvideoid();

		$query->execute();
		$comments = array();
		
		while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
			$comment = new comment($this->con, $row, $this->userloggedinobj, $videoid);
			array_push($comments, $comment);
		}
		return $comments;
	}

}


 ?>