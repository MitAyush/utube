<?php 
	/**
	 * 
	 */
	class videogrid
	{
		private $con, $categoryid, $largemode = false, $gridclass = "videogird";
		function __construct($con, $videoid)
		{
			$this->con = $con;
			$query = $con->prepare("SELECT category from videos where id = :id");
			$query->bindParam(":id", $videoid);
			$query->execute();
			$result = $query->fetch(PDO::FETCH_ASSOC);

			$this->categoryid = $result['category'];
		}

		public function create($title, $showfiler, $videoobj){
			$categoryid = $this->categoryid;
			$query = $this->con->prepare("SELECT * from videos where category = :categoryid order by RAND() limit 5");
			$query->bindParam(":categoryid", $categoryid);
			$query->execute();
			

			$html = "<span class='suggessiontitle'>$title</span>";

			while ($result = $query->fetch(PDO::FETCH_ASSOC)) {
				$thumbnails = $this->gethumbnail($result['id']);
				$title = $result['title'];
				$uploadedby = $result['uploadedby'];
				$views = $result['views'];
				$duration = $result['duration'];

				$html .= "<div class='videogrid'>
							<div class='thumbnails'>
								$thumbnails
								
							</div>
							<div class='suggessioninfo'>
								<span class='infogrid'>
									$title <br>
									<span class='gridviews'>
										<a href='profile.php?username=$uploadedby'>$uploadedby</a> <br>
										 $views  views
									</span>

								</span>
							</div>
							<span class='duration'>
								<span class='duration-background'>$duration</sapn>
							</sapn>
						</div>";
			}
			
			return $html;

		}

		private function gethumbnail($videoid){
			$query = $this->con->prepare("SELECT filepath from  thumbnails where videoid = :videoid and selected = 1");
			$query->bindParam(":videoid", $videoid);
			$query->execute();
			$result = $query->fetch(PDO::FETCH_ASSOC);
			$filepath = $result['filepath'];

			return "<a href='watch.php?id=$videoid'>
						<img src='$filepath'>
					</a>";
		}
	}

 ?>