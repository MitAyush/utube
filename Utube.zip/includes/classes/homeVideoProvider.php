<?php 
	/**
	 * 
	 */
	class HomeVideo
	{
		private $con, $profileUsername;
		function __construct($con, $profileUsername)
		{
			$this->con = $con;
			$this->profileUsername = $profileUsername;
			
		}

		public function createAboutSection($profileUserObj, $subscriberCount){
			$about = $profileUserObj->getAboutUser();
		  	$allViewCount = $profileUserObj->getAllViewsCount();
		  	$signupDate = $profileUserObj->getsignupdate();
		  	$signupDate = date("M jS Y", strtotime($signupDate));

		  	$allViewCount = $allViewCount ? $allViewCount : 0;

		  	return "<div class='about-section'>
		  				Description
		  				<span>$about</sapn>
		  				<hr>
		  				<span>Views : $allViewCount</sapn> <br>
		  				<span>Subscribers : $subscriberCount</sapn> <br>
		  				<span>Joined : $signupDate</sapn>
		  			</div>";

		}

		public function createHomeVideo(){
			$query = $this->con->prepare("SELECT * from videos where uploadedby = :uploadedby order by RAND()");
			$uploadedby = $this->profileUsername;
			$query->bindParam(":uploadedby", $uploadedby);
			$query->execute();
			

			$html = "";

			while ($result = $query->fetch(PDO::FETCH_ASSOC)) {
				$thumbnails = $this->gethumbnail($result['id']);
				$uploadedby = $result['uploadedby'];
				$views = $result['views'];
				$title = $result['title'];
				$duration = $result['duration'];

				$timeAgo = $this->time_elapsed_string($result['uploaddate']);

				$html .= "<div class='subscription'>
							<div class='sub-thumb'>
								$thumbnails
							</div>
							<span class='sub-duration-background'>
								<span class='sub-duration'>$duration</span>
							</span>
							<div class='sub-info'>
								<span class='infogrid'>
									$title <br>
									<span class='gridviews'>
										<a href='profile.php?username=$uploadedby'>$uploadedby</a> <br>
										$views  views &#8226 $timeAgo
									</span>
								</span>
							</div>
						</div>";
			}
			
			return $html;

		}

		private function gethumbnail($videoid){
			$query = $this->con->prepare("SELECT filepath from  thumbnails where videoid = :videoid and selected = 1");
			$query->bindParam(":videoid", $videoid);
			$query->execute();
			$result = $query->fetch(PDO::FETCH_ASSOC);
			$filepath = $result['filepath'];

			return "<a href='watch.php?id=$videoid'>
						<img src='$filepath'>
					</a>";		

		}

		private function time_elapsed_string($datetime, $full = false) {
		    $now = new DateTime;
		    $ago = new DateTime($datetime);
		    $diff = $now->diff($ago);

		    $diff->w = floor($diff->d / 7);
		    $diff->d -= $diff->w * 7;

		    $string = array(
		        'y' => 'year',
		        'm' => 'month',
		        'w' => 'week',
		        'd' => 'day',
		        'h' => 'hour',
		        'i' => 'minute',
		        's' => 'second',
		    );
		    foreach ($string as $k => &$v) {
		        if ($diff->$k) {
		            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
		        } else {
		            unset($string[$k]);
		        }
		    }

		    if (!$full) $string = array_slice($string, 0, 1);
		    return $string ? implode(', ', $string) . ' ago' : 'just now';
		}
	}

 ?>