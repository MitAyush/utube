<?php 
	
	class videodetailsfromprovider{

		private $con;

		public function __construct($con){
			$this->con = $con; 

		}
		public function createfromprovider(){
			$fileinput = $this->createfileinput();
			return $fileinput;
		}
		
		private function createfileinput(){
			$html =  '<form method="post" action="processing.php" enctype="multipart/form-data" style="width:85%; margin-left: 50px;">
					<div class="form-group">
					<label for="yourFile">Your File</label>
					    <input type="file" class="form-control"  id="yourFile" name="fileinput">
					  </div>
					  <div class="form-group">
						<input class="form-control form-control-lg" maxlength="70" type="text" placeholder="Title" name="title">	
					  </div>
					  <div class="form-group">
						<textarea class="form-control" maxlength="1000" id="exampleFormControlTextarea1" name="description"  placeholder="Description" rows="3"></textarea>	
					  </div>
					  <div class="form-group">
					    <select class="form-control" name="privacyinput">
					      <option value="0">Private</option>
					      <option value="1">Public</option>
					    </select>
					  </div>';

			$category = $this->getcategory();
			$html .= $category;

					  $html .= '<button type="submit" name="submit" class="btn btn-primary">Submit</button>
					</form>';
					return $html;
		}

		private function getcategory(){
			$query = $this->con->prepare("SELECT * FROM categories");
			$query->execute();
			$html = '<div class="form-group">
					    <select class="form-control" name="category">';

			while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
				$html .= '<option value="'.$row['id'].'">'.$row['name'].'</option>';
			}

			$html .= '</select>
					  </div>';
			return $html;

		}




	}

 ?>