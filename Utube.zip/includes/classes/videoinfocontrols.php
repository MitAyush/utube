<?php 
	/**
	 * 
	 */
	require 'buttonprovider.php';
	class videoinfocontrols
	{
		
		private $video, $userloggedin;
		
		function __construct($video, $userloggedin)
		{
			$this->video = $video;
			$this->userloggedin = $userloggedin;
		}

		public function createcontrols(){

			$likebutton = $this->createlikebutton();
			$dislikebutton = $this->createdislikebutton();
			return "<div class='controls'>
						$likebutton
						$dislikebutton
					</div>";
		}

		private function createlikebutton(){
			$videoid = $this->video->getvideoid();
			$text = $this->video->getlikes();
			$action = ($this->userloggedin) ? "likevideo(this, $videoid)" : "showloginmessage()";

			if ($this->video->waslikedby($this->userloggedin, $videoid)) {
				$imagesrc = "includes/images/alreadylike.png";
			}
			else{
				$imagesrc = "includes/images/like.png";
			}

			return buttonprovider::createbutton($text, $imagesrc, $action, "likebutton");
		}

		private function createdislikebutton(){
			$videoid = $this->video->getvideoid();
			$text = $this->video->getdislikes();
			$action = ($this->userloggedin) ? "dislikevideo(this, $videoid)" : "showloginmessage()";
			
			if ($this->video->wasdislikedby($this->userloggedin, $videoid)) {
				$imagesrc = "includes/images/alreadydislike.png";
			}
			else
				$imagesrc = "includes/images/dislike.png";

			return buttonprovider::createbutton($text, $imagesrc, $action, "dislikebutton");
		}








	}


 ?>