<?php 
	
	/**
 * 
 */
require_once 'buttonprovider.php';
require_once 'commentcontrol.php';
class comment
{
	private $con, $sqldata, $userloggedinobj, $videoid;
	function __construct($con, $input, $userloggedinobj, $videoid)
	{
		if (!is_array($input)) {
			$query = $con->prepare("SELECT * from comments where id = :id");
			$query->bindParam("id", $input);
			$query->execute();

			$input = $query->fetch(PDO::FETCH_ASSOC);
		}
		$this->sqldata = $input;
		$this->con = $con;
		$this->userloggedinobj = $userloggedinobj;
		$this->videoid = $videoid;
	}

	public function getcommentid(){
		return $this->sqldata['id'];
	}

	public function getvideoid(){
		return $this->videoid;
	}

	public function createcomment(){
		$userloggedin = isset($_SESSION['userloggedin']) ? $_SESSION['userloggedin'] : "";
		$commentid = $this->getcommentid();
		$videoid = $this->getvideoid();
		$body = $this->sqldata['body'];
		$postedby = $this->sqldata['postedby'];
		$profilebutton = buttonprovider::createuserbutton($this->con, $postedby);
		$timestamp = $this->time_elapsed_string($this->sqldata['dateposted']);

		$commentcontrolobj = new commentcontrol($this->con, $this->userloggedinobj, $this, $userloggedin);
		$commentcontrol = $commentcontrolobj->createcontrolsWithoutReply();

		$numreply = $this->getnumreply($commentid);

		$viewallreplytext = $numreply ? "<span class='repliessection viewreply' onclick='getreplies($commentid , this, $videoid)'>view all $numreply replies</span>" : "<div class='replysection'></div>";

		return " <div class='itemcontainer'>
					<div class='comment'>
						$profilebutton
					</div>
					<div class='displayinline'>
						<div class='maincomment'>
							<a href='profile.php?username=$postedby'>
								$postedby
							</a>
							<span class='timestamp'>$timestamp </span>
						</div>
						<div class='body'>
							$body
						</div>
						$commentcontrol
						$viewallreplytext
					</div>
				</div>";
	}

	public function createallcomment(){
		$commentid = $this->getcommentid();
		$videoid = $this->getvideoid();
		$body = $this->sqldata['body'];
		$postedby = $this->sqldata['postedby'];
		$profilebutton = buttonprovider::createuserbutton($this->con, $postedby);
		$timestamp = $this->time_elapsed_string($this->sqldata['dateposted']);

		$commentcontrolobj = new commentcontrol($this->con, $this->userloggedinobj, $this, $userloggedin);
		$commentcontrol = $commentcontrolobj->createcontrolsWithoutReply();

		$numreply = $this->getnumreply($commentid);

		$viewallreplytext = $numreply ? "<span class='repliessection viewreply' onclick='getreplies($commentid , this, $videoid)'>view all $numreply replies</span>" : "<div class='replysection'></div>";

		return " <div class='itemcontainer'>
					<div class='comment'>
						$profilebutton
					</div>
					<div class='displayinline'>
						<div class='maincomment'>
							<a href='profile.php?username=$postedby'>
								$postedby
							</a>
							<span class='timestamp'>$timestamp </span>
						</div>
						<div class='body'>
							$body
						</div>
						$commentcontrol
						$viewallreplytext
					</div>
				</div>";
	}

	public function getnumreply($responseto){
		$query = $this->con->prepare("SELECT count(*) from comments where responseto = :responseto");
		$query->bindParam(":responseto", $responseto);
		$query->execute();

		return $query->fetchColumn();
	}

	public function getnumlikes(){
		$query = $this->con->prepare("SELECT count(*) as 'count' from likes where commentid = :commentid");
		$query->bindParam(":commentid", $commentid);
		$commentid = $this->sqldata['id'];
		$query->execute();

		$data = $query->fetch(PDO::FETCH_ASSOC);

		$numlikes = $data['count'];

		$query = $this->con->prepare("SELECT count(*) as 'count' from dislikes where commentid = :commentid");
		$query->bindParam(":commentid", $commentid);
		$query->execute();

		$data = $query->fetch(PDO::FETCH_ASSOC);

		$numdislikes = $data['count'];

		return $numlikes - $numdislikes;

	}
	public function waslikedby($userloggedin, $commentid){

		$query = $this->con->prepare("SELECT * from likes where username = :username and commentid = :commentid");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":commentid", $commentid);

		$query->execute();
		return $query->rowCount();
	}

	public function wasdislikedby($userloggedin, $commentid){

		$query = $this->con->prepare("SELECT * from dislikes where username = :username and commentid = :commentid");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":commentid", $commentid);

		$query->execute();
		return $query->rowCount();
	}
	private function time_elapsed_string($datetime, $full = false) {
	    $now = new DateTime;
	    $ago = new DateTime($datetime);
	    $diff = $now->diff($ago);

	    $diff->w = floor($diff->d / 7);
	    $diff->d -= $diff->w * 7;

	    $string = array(
	        'y' => 'year',
	        'm' => 'month',
	        'w' => 'week',
	        'd' => 'day',
	        'h' => 'hour',
	        'i' => 'minute',
	        's' => 'second',
	    );
	    foreach ($string as $k => &$v) {
	        if ($diff->$k) {
	            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
	        } else {
	            unset($string[$k]);
	        }
	    }

	    if (!$full) $string = array_slice($string, 0, 1);
	    return $string ? implode(', ', $string) . ' ago' : 'just now';
	}


}

 ?>

