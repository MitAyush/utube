<?php 
	/**
	 * 
	 */
	class validation
	{
		
		public function validatefirstname($firstname)
		{
			if (strlen($firstname) < 3 || strlen($firstname) > 15) {
				return false;
			}
			return true;
			
		}
		public function validatelastname($lastname)
		{
			if (strlen($lastname) < 3 || strlen($lastname) > 15) {
				return false;
			}
			return true;
			
		}
		public function validateusername($username)
		{
			if (strlen($username) < 3 || strlen($username) > 25) {
				return false;
			}
			return true;
			
		}
		public function usernametaken($username, $con){
			$query = $con->prepare("SELECT * from users where username = :username");
			$query->bindParam(":username", $username);
			$query->execute();

			if($query->rowCount())
				return true;

			return false;
		}
		public function emailtaken($email, $con){
			$query = $con->prepare("SELECT * from users where email = :email");
			$query->bindParam(":email", $email);
			$query->execute();

			if($query->rowCount())
				return true;
			
			return false;
		}

		public function validateOldPassword($oldPassword, $con, $username){
			$query = $con->prepare("SELECT password from users where username = :username");
			$query->bindParam(":username", $username);
			$query->execute();

			return $query->fetchColumn()== $oldPassword;
		}
		
		public function validateemail($email){
			if (strlen($email) < 8 || strlen($email) > 45) {
				return false;
			}
			return true;
		}

		public function validatepassword($password){
			if (strlen($password) < 8 || strlen($password) > 25) {
				return false;
			}
			return true;
		}

	}


 ?>