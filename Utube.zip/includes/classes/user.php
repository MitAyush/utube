<?php 
	
	/**
	 * 
	 */
	class user
	{
		private $con, $sqldata;
		function __construct($con, $username)
		{
			$this->con = $con;

			$query = $this->con->prepare("SELECT * from users where username = :username");
			$query->bindParam(":username", $username);
			$query->execute();
			$this->sqldata = $query->fetch(PDO::FETCH_ASSOC);
		}


		public function getusername(){
			return $this->sqldata["username"];
		}

		public function getfirstname(){
			return $this->sqldata["firstname"];
		}

		public function getlastname(){
			return $this->sqldata["lastname"];
		}
		public function getfullname(){
			return $this->sqldata["firstname"]." ".$this->sqldata['lastname'];
		}

		public function getemail(){
			return $this->sqldata["email"];
		}

		public function getsignupdate(){
			return $this->sqldata["signupdate"];
		}
		public function getprofilepic(){
			return $this->sqldata["profilepic"];
		}

		public function getabout(){
			return $this->sqldata["about"];
		}

		public function issubscribedto($userto, $userloggedin){
			$query = $this->con->prepare("SELECT * from subscribers where userto = :userto and userfrom = :userloggedin");
			$query->bindParam(":userto", $userto);
			$query->bindParam(":userloggedin", $userloggedin);
			$query->execute();

			return $query->rowCount();
		}

		public function getsubscribercount($userto){
			$query = $this->con->prepare("SELECT * from subscribers where userto = :userto");
			$query->bindParam(":userto", $userto);
			$query->execute();

			return $query->rowCount();
		}

		public function getSubscribtionTo(){
			$query = $this->con->prepare("SELECT userto from subscribers where userfrom = :userfrom");
			$query->bindParam(":userfrom", $userfrom);
			$userfrom = $this->getusername();
			$query->execute();

			$usertoArray = array();

			while ($result = $query->fetch(PDO::FETCH_ASSOC)) {
				array_push($usertoArray, $result['userto']);
			}

			return $usertoArray;

		}

		public function getLikedVideoArray(){
			$query = $this->con->prepare("SELECT videoid from likes where username = :username and commentid = 0");
			$query->bindParam(":username", $username);
			$username = $this->getusername();
			$query->execute();

			$usertoArray = array();

			while ($result = $query->fetch(PDO::FETCH_ASSOC)) {
				array_push($usertoArray, $result['videoid']);
			}

			return $usertoArray;
		}

		public function getAboutUser(){
			$query = $this->con->prepare("SELECT about from users where username = :username");
			$query->bindParam(":username", $username);
			$username = $this->getusername();
			$query->execute();
			return $query->fetchColumn();
		}

		public function getAllViewsCount(){
			$query = $this->con->prepare("SELECT SUM(views) from videos where uploadedby = :uploadedby");
			$query->bindParam(":uploadedby", $username);
			$username = $this->getusername();
			$query->execute();
			return $query->fetchColumn();
		}


		public function isUploadedBy($videoid){
			$query = $this->con->prepare("SELECT id from videos where id = :id and  uploadedby = :uploadedby");
			$query->bindParam(":id", $videoid);
			$query->bindParam(":uploadedby", $username);
			$username = $this->getusername();
			$query->execute();
			return $query->rowCount();
		}











	}


 ?>