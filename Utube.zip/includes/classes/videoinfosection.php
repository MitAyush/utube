<?php 
	/**
	 * 
	 */
	class videoinfosection
	{
		
		private $video, $con, $userloggedin;
		
		function __construct($con, $video, $userloggedin)
		{
			$this->video = $video;
			$this->con = $con;
			$this->userloggedin = $userloggedin;
		}

		public function createinfosection($uploadedby){
			return $this->createprimaryinfo() . $this->createsecondaryinfo($uploadedby);
		}

		private function createprimaryinfo(){

			$title = $this->video->gettitle();
			$views = $this->video->getviews();

			$videoinfocontrol = new videoinfocontrols($this->video, $this->userloggedin);
			$controls = $videoinfocontrol->createcontrols();

			return "<div class='videoinfo'>
						<h1>$title</h1>

						<div class='bottomsection'>
							<span class='viewcount'> $views views $controls </span>
						</div>
					</div>";
		}

		private function createsecondaryinfo($uploadedby){
			$description = $this->video->getdescription();
			$uploadedby = $this->video->getuploadedby();
			$uploadeddate  = $this->video->getuploaddate();
			$description  = $this->video->getdescription();
			$userbutton = buttonprovider::createuserbutton($this->con, $uploadedby);

			$videoid = $this->video->getvideoid();

			if ($uploadedby == $this->userloggedin) {
				$actionbutton = buttonprovider::createeditbutton($videoid);
			}
			else{
				$usertoobj = new user($this->con, $uploadedby);
				$actionbutton = buttonprovider::createsubscribebutton($this->con, $usertoobj, $uploadedby, $this->userloggedin);
			}
			return "<div class='secondaryinfo'>
						<div class='toprow'>
							<div class='profilepic'>
								$userbutton
								<div class='uploadinfo'>
									<span class='owner'>
										<a href='profile.php?username=$uploadedby'> $uploadedby </a>
									</span>
									<span class='uploadeddate'>
										Published on $uploadeddate
									</span>
								</div>
									$actionbutton
							</div>
							<div class='description'>
								$description
							</div>

					</div>";
		}









	}


 ?>