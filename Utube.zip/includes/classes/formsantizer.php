<?php 
	/**
	 * 
	 */
	class formsantizer
	{
		
		public function srtingsantinize($str, $i){
			$str = strip_tags($str); // strip html tags
			$str = str_replace("  ", "", $str);
			$str = strtolower($str);
			if ($i) {
				$str = ucfirst($str);
			}
			return $str;
		}

		public function passwordsantinize($pwd){
			return strip_tags($pwd); // strip html tags
		}
	}

 ?>