<?php 
	/**
	 * 
	 */
	class LikeVideoProvider
	{
		private $con, $likedVideoArray, $count = 0;
		function __construct($con, $likedVideoArray)
		{
			$this->con = $con;
			$this->likedVideoArray = $likedVideoArray;
		}

		public function createLikedVideo(){
			$count = 0;
				//$query = $this->con->prepare("SELECT ")
			shuffle($this->likedVideoArray);
			$html = "<h5 class='sub-title' style='padding-top: 60px;'>Your liked videos</h5>";
			foreach ($this->likedVideoArray as $likedVideo) {
				$html .= $this->createGrid($likedVideo);
				if (++$count > 10) {
					break;
				}
			}
			if (!$this->count) {
				return $html = "<h5 class='sub-title' style='padding-top: 60px;'>You haven't liked any video</h5>";
			}

			return $html;

		}

		private function createGrid($likedVideo){
			$query = $this->con->prepare("SELECT * from videos where id = :id");
			$query->bindParam(":id", $likedVideo);
			$query->execute();
			$result = $query->fetch(PDO::FETCH_ASSOC);
			if ($result['id']) {
				$this->count++;
			}
			$thumbnails = $this->gethumbnail($result['id']);
			$duration = $result['duration'];
			$title = $result['title'];
			$uploadedby = $result['uploadedby'];
			$views = $result['views'];
			$timeAgo = $this->time_elapsed_string($result['uploaddate']);

			return "<div class='subscription'>
							<div class='sub-thumb'>
								$thumbnails
							</div>
							<span class='sub-duration-background'>
								<span class='sub-duration'>$duration</span>
							</span>
							<div class='sub-info'>
								<span class='infogrid'>
									$title <br>
									<span class='gridviews'>
										<a href='profile.php?username=$uploadedby'>$uploadedby</a> <br>
										$views  views &#8226 $timeAgo
									</span>
								</span>
							</div>

						</div>";

		}

		private function gethumbnail($videoid){
			$query = $this->con->prepare("SELECT filepath from  thumbnails where videoid = :videoid and selected = 1");
			$query->bindParam(":videoid", $videoid);
			$query->execute();
			$result = $query->fetch(PDO::FETCH_ASSOC);
			$filepath = $result['filepath'];

			return "<a href='watch.php?id=$videoid'>
						<img src='$filepath'>
					</a>";		

		}

		private function time_elapsed_string($datetime, $full = false) {
		    $now = new DateTime;
		    $ago = new DateTime($datetime);
		    $diff = $now->diff($ago);

		    $diff->w = floor($diff->d / 7);
		    $diff->d -= $diff->w * 7;

		    $string = array(
		        'y' => 'year',
		        'm' => 'month',
		        'w' => 'week',
		        'd' => 'day',
		        'h' => 'hour',
		        'i' => 'minute',
		        's' => 'second',
		    );
		    foreach ($string as $k => &$v) {
		        if ($diff->$k) {
		            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
		        } else {
		            unset($string[$k]);
		        }
		    }

		    if (!$full) $string = array_slice($string, 0, 1);
		    return $string ? implode(', ', $string) . ' ago' : 'just now';
		}

	}


 ?>