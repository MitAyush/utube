<?php 

	class commentsection
	{
		
		private $videoobj, $con, $userloggedin;
		
		function __construct($con, $videoobj, $userloggedin)
		{
			$this->videoobj = $videoobj;
			$this->con = $con;
			$this->userloggedin = $userloggedin;
		}
		public function create(){
			return $this->createcommentsection();
		}
		private function createcommentsection(){
			$postedby = $this->userloggedin;
			$videoid = $this->videoobj->getvideoid();
			$numcomments = $this->videoobj->getnumofcomments()." comments";

			$profilebutton = buttonprovider::createuserbutton($this->con, $postedby);
			$commentaction = "postcomment(this, \"$postedby\", \"$videoid\", null, \"comments\")";
			$commentbutton = buttonprovider::createbutton("COMMENT", null, $commentaction, "postcomment");

			$allcomments = $this->videoobj->getallcomments();
			$commentitems = "";
			foreach ($allcomments as $comment) {
				$commentitems .= $comment->createcomment();
			}

			return "<div class='commentsection'>
						<br>
						<div class='header'>
							<span class='numcomment'> $numcomments </span>
						</div>

						<div class='maincomments'>
							$profilebutton
							$commentbutton

							<span class='commentarea'>
								<textarea class='mycomment' cols='55' placeholder='Add Public Comment...'></textarea>
							</span>
						</div>
						<div class='commentbutton'>
							
						</div>

						<div class='comments'>
							$commentitems
						</div>

					</div>";	


		}


	}

 ?>

