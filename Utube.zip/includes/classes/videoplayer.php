<?php 
	/**
	 * 
	 */
	class videoplayer
	{	
		private $video;
		
		function __construct($video)
		{
			$this->video = $video;
		}

		public function createvideoplayer($autoplay){
			if ($autoplay) {
				$autoplay = "autoplay";
			}
			else{
				$autoplay = "";
			}
			$filepath = $this->video->getfilepath();
			return "<video class='videoplayer' controls $autoplay>
					<source src='$filepath' type='video/mp4'>
					your browser doesn't support Mp4 videos
				</video>";
		}
	}


 ?>