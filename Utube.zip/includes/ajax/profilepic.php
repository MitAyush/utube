<?php 
	require '../config.php';
	if (!isset($_FILES['profilePic']['name'])) {
		exit();
	}

	$userloggedin = $_SESSION['userloggedin'];

	$file_name = $_FILES['profilePic']['name'];
	$file_size =$_FILES['profilePic']['size'];
	$file_tmp =$_FILES['profilePic']['tmp_name'];
	$file_type=$_FILES['profilePic']['type'];
	$file_ext=strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

	$extensions= array("jpeg","jpg","png");

	if(in_array($file_ext,$extensions) === false){
	 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
	}

	if($file_size > 300000){
	 $errors[]='File size must be less than 300KB';
	}
	$finalFileName = uniqid().'_'.$file_name;
	if(empty($errors)==true){
		 move_uploaded_file($file_tmp,"../images/profilepic/".$finalFileName);
		 /*=============== update database ==========================*/

		$query = $con->prepare("UPDATE users set profilepic = :imagePath where username = :userloggedin");
		$query->bindParam(":imagePath", $imagePath);
		$query->bindParam(":userloggedin", $userloggedin);
		$imagePath = "includes/images/profilepic/".$finalFileName;
		$query->execute();
	}
	else{
		foreach ($errors as $error) {
			echo $error;
		}
	}


 ?>