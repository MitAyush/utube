<?php 

	require '../config.php';
	$id = isset($_POST['videoid']);
	if (!$id) {
		exit();
	}
	$videoid  = $_POST['videoid'];
	
	$userloggedin = $_SESSION['userloggedin'];

	$query = $con->prepare("SELECT * from likes where username = :username and videoid = :videoid");
	$query->bindParam(":username", $userloggedin);
	$query->bindParam(":videoid", $videoid);
	$query->execute();

	if ($query->rowCount()) {
		$query = $con->prepare("DELETE from likes where username = :username and videoid = :videoid");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":videoid", $videoid);
		$query->execute();

		$result = array(
				"likes" => -1,
				"dislikes" => 0
		);

		echo json_encode($result);

	}
	else{
		$query = $con->prepare("INSERT into likes (username, videoid) values (:username, :videoid)");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":videoid", $videoid);
		$query->execute();

		/*===============delete from dislike table ==================*/
		$query = $con->prepare("DELETE from dislikes where username = :username and videoid = :videoid");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":videoid", $videoid);
		$query->execute();

		$count = $query->rowCount();

		$result = array(
				"likes" => 1,
				"dislikes" => 0 - $count
		);

		echo json_encode($result);
	}

 ?>