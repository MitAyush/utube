<?php 

	require '../config.php';
	$id = isset($_POST['commentid']);
	$userloggedin = $_SESSION['userloggedin'];
	if (!$id && !$userloggedin) {
		exit();
	}
	$videoid  = $_POST['videoid'];
	$commentid  = $_POST['commentid'];
	
	

	$query = $con->prepare("SELECT * from likes where username = :username and commentid = :commentid");
	$query->bindParam(":username", $userloggedin);
	$query->bindParam(":commentid", $commentid);
	$query->execute();

	if ($query->rowCount()) {
		$query = $con->prepare("DELETE from likes where username = :username and commentid = :commentid");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":commentid", $commentid);
		$query->execute();

		echo -1;

	}
	else{
		//*===============delete from dislike table ==================
		$query = $con->prepare("DELETE from dislikes where username = :username and commentid = :commentid");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":commentid", $commentid);
		$query->execute();
		$count = $query->rowCount();

		//*============== Insert into likes table ==================

		$query = $con->prepare("INSERT into likes (username, commentid) values (:username, :commentid)");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":commentid", $commentid);
		$query->execute();

		



		echo  1 + $count;
	}

 ?>