<?php 

	require '../config.php';
	require_once '../classes/comment.php';
	require_once '../classes/user.php';
	$id = isset($_POST['replyto']);
	if (!$id) {
		exit();
	}
	$replyto  = $_POST['replyto'];
	$videoid  = $_POST['videoid'];

	$username = $_SESSION['userloggedin'];
		
	$query = $con->prepare("SELECT * from comments where responseto = :replyto order by dateposted DESC");
	$query->bindParam(":replyto", $replyto);
	$query->execute();

	$comments = "";
	$userloggedinobj = new user($con, $username);
	
	while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
		$comment = new comment($con, $row, $userloggedinobj, $videoid);
		$comments .= $comment->createcomment();
	}
	
	echo $comments;

 ?>