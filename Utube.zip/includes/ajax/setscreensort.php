<?php 

	require '../config.php';
	$id = isset($_POST['videoid']);
	if (!$id) {
		exit();
	}
	$videoid  = $_POST['videoid'];
	$id  = $_POST['id'];
	
	$query = $con->prepare("UPDATE thumbnails set selected = 0 where videoid = :videoid");
	$query->bindParam(":videoid", $videoid);
	$query->execute();

	$query = $con->prepare("UPDATE thumbnails set selected = 1 where id = :id");
	$query->bindParam(":id", $id);
	$query->execute();
 ?>