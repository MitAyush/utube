<?php 
	require '../config.php';
	require '../classes/comment.php';
	require '../classes/user.php';
	$id = isset($_POST['commentid']);
	if (!$id) {
		exit();
	}

	$postedby  = $_POST['postedby'];
	$commentid  = $_POST['commentid'];
	$commenttext  = $_POST['commenttext'];
	$replyto  = $_POST['replyto'];

	$videoid = 0;
	$query = $con->prepare("INSERT into comments (postedby, videoid, responseto, body) values (:postedby, :videoid, :responseto, :commenttext)");
	$query->bindParam(":postedby", $postedby);
	$query->bindParam(":videoid", $videoid);
	$query->bindParam(":responseto", $replyto);
	$query->bindParam(":commenttext", $commenttext);
	$query->execute();

	$lastinsertedid =  $con->lastInsertId();

	$userloggedinobj = new user($con, $_SESSION['userloggedin']);
	$newcomment = new comment($con, $lastinsertedid, $userloggedinobj, $videoid);

	echo $newcomment->createcomment();

 ?>