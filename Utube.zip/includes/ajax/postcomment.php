<?php 
	require '../config.php';
	require '../classes/comment.php';
	require '../classes/user.php';
	$userloggedin = isset($_SESSION['userloggedin']) ? $_SESSION['userloggedin'] : "";
	$id = isset($_POST['videoid']);
	if (!$id || (!$userloggedin)) {
		echo "<script>alert('Please Login to comment');</script>";
		exit();
	}

	$videoid  = $_POST['videoid'];
	$postedby  = $_POST['postedby'];
	$commenttext  = $_POST['commenttext'];

	$replyto = (isset($_POST['replyto'])) ? $_POST['replyto'] : 0;

	$query = $con->prepare("INSERT into comments (postedby, videoid, responseto, body) values (:postedby, :videoid, :responseto, :commenttext)");
	$query->bindParam(":postedby", $postedby);
	$query->bindParam(":videoid", $videoid);
	$query->bindParam(":responseto", $replyto);
	$query->bindParam(":commenttext", $commenttext);
	$query->execute();

	$lastinsertedid =  $con->lastInsertId();

	$userloggedinobj = new user($con, $userloggedin);
	$newcomment = new comment($con, $lastinsertedid, $userloggedinobj, $videoid);

	echo $newcomment->createcomment();

 ?>