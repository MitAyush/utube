<?php 

	require '../config.php';
	$id = isset($_POST['videoid']);
	$userloggedin = $_SESSION['userloggedin'];

	if (!$id && !$userloggedin) {
		exit();
	}
	$videoid  = $_POST['videoid'];

	$query = $con->prepare("SELECT * from dislikes where username = :username and videoid = :videoid");
	$query->bindParam(":username", $userloggedin);
	$query->bindParam(":videoid", $videoid);
	$query->execute();

	if ($query->rowCount()) {
		$query = $con->prepare("DELETE from dislikes where username = :username and videoid = :videoid");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":videoid", $videoid);
		$query->execute();

		$result = array(
				"dislikes" => -1,
				"likes" => 0
		);

		echo json_encode($result);

	}
	else{
		$query = $con->prepare("INSERT into dislikes (username, videoid) values (:username, :videoid)");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":videoid", $videoid);
		$query->execute();

		/*===============delete from dislike table ==================*/
		$query = $con->prepare("DELETE from likes where username = :username and videoid = :videoid");
		$query->bindParam(":username", $userloggedin);
		$query->bindParam(":videoid", $videoid);
		$query->execute();

		$count = $query->rowCount();

		$result = array(
				"dislikes" => 1,
				"likes" => 0 - $count
		);

		echo json_encode($result);
	}

 ?>