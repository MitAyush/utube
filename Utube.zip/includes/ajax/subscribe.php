<?php 
	
	require '../config.php';
	$id  = isset($_POST['userto']);
	if (!$id) {
		exit();
	}
	$userto = $_POST['userto'];
	$userfrom = $_POST['userfrom'];

	$query = $con->prepare("SELECT * from subscribers where userto = :userto and userfrom = :userfrom");
	$query->bindParam(":userto", $userto);
	$query->bindParam(":userfrom", $userfrom);
	$query->execute();

	if ($query->rowCount()) {
		$query = $con->prepare("DELETE from subscribers where userto = :userto and userfrom = :userfrom");
		$query->bindParam(":userto", $userto);
		$query->bindParam(":userfrom", $userfrom);
		$query->execute();
	}
	else{
		$query = $con->prepare("INSERT into subscribers (userto, userfrom) values (:userto, :userfrom)");
		$query->bindParam(":userto", $userto);
		$query->bindParam(":userfrom", $userfrom);
		$query->execute();
	}

	$query = $con->prepare("SELECT * from subscribers where userto = :userto");
	$query->bindParam(":userto", $userto);
	$query->execute();

	echo $query->rowCount();
	

	/*$result = array(
			"subscriber" => 1
		);
	echo json_encode($result);*/

 ?>