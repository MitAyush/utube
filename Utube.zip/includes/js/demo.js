$(document).ready(function(){
	/*$(".sidebarIconToggle").on("click", function(){
		var main = $(".mainsection");
		main.toggleClass("leftpadding");

	});*/
});

function subscribe(userto, userfrom, btn){
	if (userfrom == userto) {
		swal("Error!", "You can not subscribe to yourself", "error");
		return;
	}

	$.post("includes/ajax/subscribe.php", {userto: userto, userfrom: userfrom}).done(function(data){
		var button = $(btn);
		if (data != null) {
			button.toggleClass("subscribe unsubscribe");
			var buttontext = button.hasClass("subscribe") ? "SUBSCRIBE" : "SUBSCRIBED";
			button.text(buttontext + " " + data);
		}

		/*var element = btn.find(".text");
		var num = parseInt(element.text());
		element.text(num + 1);*/
	});
}

function oldest(item, btn){
	//alert(item);
	window.open("http://localhost/utube/getSearchResult.php?search="+item+"&orderBy=uploaddate&type=asc", "_self");
	/*var button = $(btn);
	button.siblings(".btn").removeClass("btn btn-primary");
	button.addClass("btn btn-primary");*/
}
function latest(item, btn){
	window.open("http://localhost/utube/getSearchResult.php?search="+item+"&orderBy=uploaddate","_self");
	/*var button = $(btn);
	button.siblings(".btn").removeClass("btn btn-primary");
	button.addClass("btn btn-primary");*/
}
function mostViewed(item, btn){
	window.open("http://localhost/utube/getSearchResult.php?search="+item, "_self");
	/*var button = $(btn);
	button.siblings(".btn").removeClass("btn btn-primary");
	button.addClass("btn btn-primary");*/
}
function leastViewed(item, btn){
	window.open("http://localhost/utube/getSearchResult.php?search="+item+"&type=asc", "_self");
	/*var button = $(btn);
	button.siblings(".btn").removeClass("btn btn-primary");
	button.addClass("btn btn-primary");*/
}

function setSelected(btn, videoid, id){
	$.post("includes/ajax/setscreensort.php", {videoid :videoid, id : id}).done(function(){
		var button = $(btn);
		button.siblings().removeClass('selected');
		button.addClass('selected');
		swal("Thumbnail updated");
	});
}