$(document).ready(function(){
	$("#gosignup").click(function() {
		$(".login").hide(500);
		$('.signupclass').show(600);
		//return false;

	});

	$("#gologin").click(function() {
		$(".signupclass").hide(500);
		$('.login').show(600);
		//return false;

	});
});