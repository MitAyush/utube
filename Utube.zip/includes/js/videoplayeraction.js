function likevideo(btn, videoid) {
	$.post("includes/ajax/likevideo.php", {videoid: videoid})
	.done(function(data){
		var likebutton = $(btn);
		var dislikebutton = $(btn).siblings(".dislikebutton");

		likebutton.addClass("active");
		dislikebutton.removeClass("active");

		var result = JSON.parse(data);
		updatevalues(likebutton.find(".text"), result.likes);
		updatevalues(dislikebutton.find(".text"), result.dislikes);

		if (result.likes < 0) {
			likebutton.find("img:first").attr("src", "includes/images/like.png");
			likebutton.removeClass("active");

		}
		else{
			likebutton.find("img:first").attr("src", "includes/images/alreadylike.png");

		}
		dislikebutton.find("img:first").attr("src", "includes/images/dislike.png");

	});

}

function dislikevideo(btn, videoid){
	$.post("includes/ajax/dislikevideo.php", {videoid: videoid})
	.done(function(data){
		var dislikebutton = $(btn);
		var likebutton = $(btn).siblings(".likebutton");

		likebutton.removeClass("active");
		dislikebutton.addClass("active");

		var result = JSON.parse(data);
		updatevalues(likebutton.find(".text"), result.likes);
		updatevalues(dislikebutton.find(".text"), result.dislikes);

		if (result.dislikes < 0) {
			dislikebutton.find("img:first").attr("src", "includes/images/dislike.png");
			dislikebutton.removeClass("active");

		}
		else{
			dislikebutton.find("img:first").attr("src", "includes/images/alreadydislike.png");
		}
		
		likebutton.find("img:first").attr("src", "includes/images/like.png");

	});
}

function updatevalues(element, num){
	var likescountval = element.text() || 0;
	element.text(parseInt(likescountval) + parseInt(num));
}

function showloginmessage(){
	alert("please login");
}