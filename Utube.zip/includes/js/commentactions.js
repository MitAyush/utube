function postcomment(btn, postedby, videoid, replyto, classcontainer){
	var textarea = $(".mycomment");
	var commenttext = textarea.val();
	if (!postedby) {
		alert("You must login to comment");
		return;
	}
	textarea.val("");

	if (commenttext) {
		$.post("includes/ajax/postcomment.php", {postedby :postedby, videoid: videoid,
			commenttext: commenttext, replyto: replyto}).done(function(data){
			$('.' + classcontainer).prepend(data);
		});
	}
	else{
		alert("no  comment");
	}
}
function postreply(btn, postedby, commentid, replyto, classcontainer){
	var textarea = $(btn).siblings(".commentarea").children(".mycomment");
	var commenttext = textarea.val();
	if (!postedby) {
		alert("You must login to comment");
		return;
	}
	textarea.val("");
	if (commenttext) {
		$.post("includes/ajax/postreply.php", {postedby: postedby, commentid: commentid,
		 replyto: replyto, commenttext: commenttext}).done(function(data){
		 	$('.' + classcontainer).prepend(data);
		 });
	}
	else
		alert("No text in reply");

}
function getreplies(replyto, btn, videoid){
	
	$.post("includes/ajax/viewreplies.php", {replyto: replyto, videoid: videoid}).done(function(comments){
			var replies = $("<div>").addClass("repliessection");
			replies.append(comments);
			$(btn).replaceWith(replies);
	});
}


function togglereply(btn){
	var parent = $(btn).closest(".itemcontainer"); //closest go to parent element and find class itemcontainer
	var commentform = parent.find(".commentform").first(); //find go to child elements and find class commentform
	commentform.toggleClass("hideit");
}

function likecomment(commentid, btn, videoid){
	$.post("includes/ajax/likecomment.php", {videoid: videoid , commentid: commentid})
	.done(function(data){
		var likebutton = $(btn);
		var dislikebutton = $(btn).siblings(".dislikebutton");

		likebutton.addClass("active");
		dislikebutton.removeClass("active");

		var numlikes = likebutton.siblings(".likescount");
		updatevalues(numlikes, data);

		if (data < 0) {
			likebutton.find("img:first").attr("src", "includes/images/like.png");
			likebutton.removeClass("active");

		}
		else{
			likebutton.find("img:first").attr("src", "includes/images/alreadylike.png");

		}
		dislikebutton.find("img:first").attr("src", "includes/images/dislike.png");

	});
}

function dislikecomment(commentid, btn, videoid){
	$.post("includes/ajax/dislikecomment.php", {videoid: videoid , commentid: commentid})
	.done(function(data){
		var dislikebutton = $(btn);
		var likebutton = $(btn).siblings(".likebutton");

		likebutton.addClass("active");
		dislikebutton.removeClass("active");

		var numlikes = likebutton.siblings(".likescount");
		updatevalues(numlikes, data);

		if (data > 0) {
			dislikebutton.find("img:first").attr("src", "includes/images/dislike.png");
			dislikebutton.removeClass("active");

		}
		else{
			dislikebutton.find("img:first").attr("src", "includes/images/alreadydislike.png");

		}
		likebutton.find("img:first").attr("src", "includes/images/like.png");

	});
}

function updatevalues(element, num){
	var likescountval = element.text() || 0;
	element.text(parseInt(likescountval) + parseInt(num));
}

function showloginmessage(){
	alert("please login");
}