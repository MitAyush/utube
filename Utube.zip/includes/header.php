<?php 
require 'includes/config.php';
require 'includes/classes/user.php';

	if (isset($_COOKIE['userloggedin'])) {
			$expiry = time() + (60*60);
			setcookie('userloggedin', $_COOKIE['userloggedin'], $expiry);
			$_SESSION['userloggedin'] = $_COOKIE['userloggedin'];
		}

	$userloggedin = isset($_SESSION['userloggedin']) ? $_SESSION['userloggedin'] : "";
	$userloggedinobj = new user($con, $userloggedin);
	$profilepic = $userloggedinobj->getprofilepic();

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="includes/css/demo.css">


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

	<script type="text/javascript" src="includes/js/demo.js"></script>
</head>
<body>

	 <div class="header">
	    <a href="index.php" class="site-icon" style="text-decoration: none;">&nbsp &nbsp <img src="includes/images/logo.png" class="logo">Utube</a>
	    <form action="getSearchResult.php" method="GET" class="formcls">
	      <input type="text" name="search" placeholder="Search"> 
	      <button class="searchbutton"><img src="includes/images/search.png"></button>
	    </form>

	    <div class="button">
			<a href="upload.php"><img src="includes/images/uploadvideo.png" title="Upload Image" class="headericon"></a>
			<a href=""><img src="includes/images/bell.png" title="Notification" class="headericon"></a>
			
			<?php 
				if (isset($_SESSION['userloggedin'])) {
					echo "<a href='profile.php?username=$userloggedin'><img src='$profilepic' class='headericon btn-profilepic' title='$userloggedin'></a>";
				}
				else{
					echo '<a href="signin.php"><span class="btn btn-primary" title="Sign In">SIGN IN</span></a>';
				}
			 ?>

		</div>
	  </div>
	  
	  <input type="checkbox" class="openSidebarMenu" id="openSidebarMenu">
	  <label for="openSidebarMenu" class="sidebarIconToggle">
	    <div class="spinner diagonal part-1"></div>
	    <div class="spinner horizontal"></div>
	    <div class="spinner diagonal part-2"></div>
	  </label>

	  <div id="sidebarMenu">
	    <ul class="sidebarMenuInner">
	      <!-- <li>Jelena Jovanovic <span>Web Developer</span></li> -->
	      <a href="index.php" target="_self" style="text-decoration: none;">
		      <li>
		      	 <img src="includes/images/home.png"> &nbsp Home
		      </li>
	      </a>
	      <a href="trending.php" target="_self" style="text-decoration: none;">
		      <li>
		      	 <img src="includes/images/trending.png"> &nbsp trending
		      </li>
	      </a>
	      <a href="fullsubscription.php" target="_self" style="text-decoration: none;">
		      <li>
		      	 <img src="includes/images/subscription.png"> &nbsp subscription
		      </li>
	      </a>
	      <a href="likedvideo.php" target="_self" style="text-decoration: none;">
		      <li>
		      	 <img src="includes/images/like.png"> &nbsp liked Video
		      </li>
	      </a>
	      <a href="setting.php" target="_self" style="text-decoration: none;">
		      <li>
		      	 <img src="includes/images/setting.png"> &nbsp setting
		      </li>
	      </a>

	      <?php 
	      	if (isset($_SESSION['userloggedin'])) {
	      		$href = 'logout.php';
	      		$navText = 'Logout';
	      	}
	      	else{
	      		$href = 'signin.php';
	      		$navText = 'SIGN IN';
	      	}
	       ?>
	       <a href='<?php echo $href; ?>' target="_self" style="text-decoration: none;">
		      <li>
		      	 <img src="includes/images/logout.png"> &nbsp <?php echo $navText; ?>
		      </li>
	      </a>

	     <hr>

	     <span>Subscriptions</span>
	     <!--                  getting subscription id for userloggedin               -->
	     <?php 
	     	if (isset($_SESSION['userloggedin'])) {
	     		$subscriptionArray = $userloggedinobj->getSubscribtionTo();
		     	$html = "";
		     	foreach ($subscriptionArray as $sub) {
		     		$query = $con->prepare("SELECT profilepic from users where username = :username");
		     		$query->bindParam(":username", $sub);
		     		$query->execute();
		     		$result = $query->fetch(PDO::FETCH_ASSOC);
		     		$src = $result['profilepic'];
		     		$html .= "<a href='profile.php?username=$sub' target='_self' style='text-decoration: none;''>
							      <li>
							      	 <img src='$src'> &nbsp $sub
							      </li>
						      </a>";
		     	}

		     	echo $html;
	     	}

	      ?>

	    </ul>
	  </div>









	<!-- <div class="top">
		<button class="navshowhide"><i class="fas fa-bars fa-2x"></i></button>
		<a href="index.php" class="site-icon">Utube</a>
		<form action="getSearchResult.php" method="GET" class="formcls">
			<input type="text" name="search" placeholder="Search"> 
			<button class="searchbutton"><img src="includes/images/search.png"></button>
		</form>
		<div class="button">
			<a href="upload.php"><img src="includes/images/uploadvideo.png" class="headericon"></i></a>
			<a href=""><img src="includes/images/bell.png" class="headericon"></i></a>
			<a href=""><img src="<?php echo $profilepic ?>" class="headericon"></i></a>
		</div>
	</div>
	<div class="sidenav" style="display: none;">
		sidenav
	</div> -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>
</html>