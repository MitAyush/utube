<!DOCTYPE html>
<html>
<head>
	<title>Subscription</title>
</head>
<style>
	.test{
		float: left;
   		width: 100%;
	}
</style>
<body>
	<?php 
		require 'includes/header.php';

		if (!isset($_SESSION['userloggedin'])) {
			header("Location:signin.php");
		}
		require_once 'includes/classes/fullsubscriptionprovider.php';
	 ?>
	<div class="mainsection">
		<div class="maincontent">
			<?php 

				$userToArray = $userloggedinobj->getSubscribtionTo();
	
				$subscriptionVideo = new subscriptionProvider($con, $userToArray);
				echo $subscriptionVideo->fullSubscriptionVideos();
				
			 ?>
		</div>
	</div>
</body>
</html>