-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2020 at 11:26 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `utube`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Games'),
(2, 'Music'),
(3, 'Films'),
(4, 'Sports'),
(5, 'News & style'),
(6, 'Travelling'),
(7, 'Education'),
(8, 'Science'),
(9, 'Comedy'),
(10, 'Cartoon');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `postedby` varchar(50) NOT NULL,
  `videoid` int(11) NOT NULL,
  `responseto` int(11) NOT NULL,
  `body` text NOT NULL,
  `dateposted` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `postedby`, `videoid`, `responseto`, `body`, `dateposted`) VALUES
(1, 'shanu', 7, 0, 'hii', '2020-02-29 18:56:43'),
(4, 'shanu', 7, 0, 'hi', '2020-03-01 12:27:46'),
(5, 'ayush', 15, 0, 'aacha video hai', '2020-03-01 13:36:17'),
(6, 'ayush', 14, 0, 'Nice Song Nazam Nazam', '2020-03-01 13:37:55');

-- --------------------------------------------------------

--
-- Table structure for table `dislikes`
--

CREATE TABLE `dislikes` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `commentid` int(11) NOT NULL,
  `videoid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `commentid` int(11) NOT NULL,
  `videoid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `username`, `commentid`, `videoid`) VALUES
(7, 'ayush', 5, 0),
(8, 'ayush', 0, 15),
(9, 'ayush', 0, 14),
(10, 'ayush', 6, 0),
(11, 'shanu', 0, 14);

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL,
  `userto` varchar(50) NOT NULL,
  `userfrom` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `userto`, `userfrom`) VALUES
(26, 'shanu', 'ayush');

-- --------------------------------------------------------

--
-- Table structure for table `thumbnails`
--

CREATE TABLE `thumbnails` (
  `id` int(11) NOT NULL,
  `videoid` int(11) NOT NULL,
  `filepath` varchar(250) NOT NULL,
  `selected` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thumbnails`
--

INSERT INTO `thumbnails` (`id`, `videoid`, `filepath`, `selected`) VALUES
(1, 1, 'uploads/videos/thumbnails/1-5e4eb07f599e8.jpg', 0),
(2, 1, 'uploads/videos/thumbnails/1-5e4eb082c47aa.jpg', 0),
(3, 1, 'uploads/videos/thumbnails/1-5e4eb087a401c.jpg', 1),
(4, 2, 'uploads/videos/thumbnails/1-5e4eb07f599e8.jpg', 1),
(5, 3, 'uploads/videos/thumbnails/1-5e4eb07f599e8.jpg', 1),
(6, 4, 'uploads/videos/thumbnails/1-5e4eb07f599e8.jpg', 1),
(7, 5, 'uploads/videos/thumbnails/1-5e4eb07f599e8.jpg', 1),
(8, 6, 'uploads/videos/thumbnails/1-5e4eb07f599e8.jpg', 1),
(9, 7, 'uploads/videos/thumbnails/1-5e4eb07f599e8.jpg', 1),
(10, 8, 'uploads/videos/thumbnails/1-5e4eb07f599e8.jpg', 1),
(11, 9, 'uploads/videos/thumbnails/9-5e5b646836c08.jpg', 1),
(12, 9, 'uploads/videos/thumbnails/9-5e5b646cd8558.jpg', 0),
(13, 9, 'uploads/videos/thumbnails/9-5e5b647282760.jpg', 0),
(14, 10, 'uploads/videos/thumbnails/10-5e5b64e8c891d.jpg', 1),
(15, 10, 'uploads/videos/thumbnails/10-5e5b64ea5a86c.jpg', 0),
(16, 10, 'uploads/videos/thumbnails/10-5e5b64eef1220.jpg', 0),
(17, 14, 'uploads/videos/thumbnails/14-5e5b6a161a816.jpg', 1),
(18, 14, 'uploads/videos/thumbnails/14-5e5b6a19cee75.jpg', 0),
(19, 14, 'uploads/videos/thumbnails/14-5e5b6a1bb181f.jpg', 0),
(20, 15, 'uploads/videos/thumbnails/15-5e5b6c156bd65.jpg', 1),
(21, 15, 'uploads/videos/thumbnails/15-5e5b6c1782a47.jpg', 0),
(22, 15, 'uploads/videos/thumbnails/15-5e5b6c1d753ef.jpg', 0),
(23, 16, 'uploads/videos/thumbnails/16-5e5e556ee5005.jpg', 0),
(24, 16, 'uploads/videos/thumbnails/16-5e5e5570e8d3a.jpg', 0),
(25, 16, 'uploads/videos/thumbnails/16-5e5e5574ea955.jpg', 1),
(26, 17, 'uploads/videos/thumbnails/17-5e5f7fff1b5ca.jpg', 0),
(27, 17, 'uploads/videos/thumbnails/17-5e5f7fff8f680.jpg', 0),
(28, 17, 'uploads/videos/thumbnails/17-5e5f7ffff16c0.jpg', 1),
(29, 18, 'uploads/videos/thumbnails/18-5e61c543d3178.jpg', 0),
(30, 18, 'uploads/videos/thumbnails/18-5e61c549ed60f.jpg', 1),
(31, 18, 'uploads/videos/thumbnails/18-5e61c54da6a6b.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(15) NOT NULL,
  `lastname` varchar(15) NOT NULL,
  `username` varchar(25) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `signupdate` datetime NOT NULL DEFAULT current_timestamp(),
  `profilepic` varchar(255) NOT NULL,
  `about` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `email`, `password`, `signupdate`, `profilepic`, `about`) VALUES
(1, 'Ayush', 'Kumar', 'ayush', 'ayush@gmail.com', 'd0521106f6ba7f9ac0a7370fb28d0ec6vko5m5m5m5skls', '2020-02-20 21:39:23', 'includes/images/profilepic/5e5a605609108_aaa.jpg', ''),
(2, 'Shanu', 'Kumar', 'shanu', 'shanu@gmail.com', 'd0521106f6ba7f9ac0a7370fb28d0ec6vko5m5m5m5skls', '2020-02-20 21:39:52', 'includes/images/profilepic/5e5a64483ddbb_aa.jpg', 'This is the first channel of the website.'),
(3, 'Rahul', 'Kumar', 'rahul', 'rahul@gmail.com', 'd0521106f6ba7f9ac0a7370fb28d0ec6vko5m5m5m5skls', '2020-02-20 21:40:08', 'includes/images/profilepic/5e5a605609108_aaa.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `uploadedby` varchar(50) NOT NULL,
  `title` varchar(70) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `privacy` int(11) NOT NULL,
  `filepath` varchar(250) NOT NULL,
  `category` int(11) NOT NULL,
  `uploaddate` datetime NOT NULL DEFAULT current_timestamp(),
  `views` int(11) NOT NULL,
  `duration` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `uploadedby`, `title`, `description`, `privacy`, `filepath`, `category`, `uploaddate`, `views`, `duration`) VALUES
(9, 'shanu', 'Tom and jerry ', 'Get all the video of tom and jerry.', 1, 'uploads/videos/5e5b6421a53ee.mp4', 10, '2020-03-01 12:58:33', 2, '03:10'),
(10, 'shanu', 'Goldberg Spears Wyatt 4 times: WWE Super ShowDown 2020', 'WWE Hall of Famer Goldberg repeatedly Spears Universal Champion “The Fiend” Bray Wyatt. Catch WWE action on WWE Network, FOX, USA Network, Sony India and more', 1, 'uploads/videos/5e5b64c3bde81.mp4', 4, '2020-03-01 13:01:15', 4, '01:27'),
(14, 'shanu', 'Bareilly Ki Barfi | Kriti Sanon, Ayushmann Khurrana & Rajkummar Rao', 'Presenting the lyrical video of \'Nazm Nazm\' from the film \'Bareilly Ki Barfi\' starring Kriti Sanon and Ayushmann Khurrana.\r\nSong Name: Nazm Nazm\r\nSinger: Arko\r\nMusic: Arko\r\nLyrics: Ark', 1, 'uploads/videos/5e5b69dd56731.mp4', 2, '2020-03-01 13:23:01', 12, '03:55'),
(15, 'ayush', 'Ben 10 | Big Bad Moth! | Cartoon Network UK 🇬🇧', 'Welcome to the official Cartoon Network UK 🇬🇧 YouTube channel! The place where you can😂Watch funny videos, 🎤 singalongs and 🎮 gameplays from all your favourite cartoons: Adventure Time, The Amazing World of Gumball, Ben 10, Steven Universe, Teen Titans Go!, The Powerpuff Girls, We Bare Bears and many more. Get ready to laugh out loud and join us by subscribing to the channel!', 1, 'uploads/videos/5e5b6beccbdca.mp4', 10, '2020-03-01 13:31:48', 1, '03:06'),
(16, 'shanu', 'GARMI | New Hindi Songs 2020 | Best INDIAN Songs 2020', 'Presenting Garmi song composed xu0026 penned by Badshah. This foot-tapping soundtrack is sung by Neha Kakkar, Badshah. The movie features Varun Dhawan, Shraddha Kapoor, Nora Fatehi, and Prabhu Deva in lead roles and directed by Remo D\'Souza, produced by Bhushan Kumar, Divya Khosla Kumar, Krishan Kumar xu0026 Lizelle D’Souza.', 1, 'uploads/videos/5e5e5535d1071.mp4', 2, '2020-03-03 18:31:41', 2, '02:40'),
(17, 'shanu', 'Jumping video ', 'Guy is jumping form wall', 1, 'uploads/videos/5e5f7ff98f261.mp4', 4, '2020-03-04 15:46:25', 2, '00:09'),
(18, 'shanu', 'Padmaavat: Khalibali-Ranveer Singh | Deepika Padukone | Shahid Kapoor', 'Presenting the video song \"Khalibali\"from the bollywood movie \"Padmaavat\" in the voice ofShivam Pathak, Music by Sanjay Leela Bhansali and Lyrics by A M Turaz.', 1, 'uploads/videos/5e61c4f444ad2.mp4', 2, '2020-03-06 09:05:16', 1, '03:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dislikes`
--
ALTER TABLE `dislikes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thumbnails`
--
ALTER TABLE `thumbnails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `dislikes`
--
ALTER TABLE `dislikes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `thumbnails`
--
ALTER TABLE `thumbnails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
