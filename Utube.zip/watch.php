<!DOCTYPE html>
<html>
<head>
	<title>Watch</title>
</head>
<body>
	<script src="includes/js/videoplayeraction.js"></script>
	<script src="includes/js/commentactions.js"></script>
	<?php 
	require 'includes/header.php'; 
	require 'includes/classes/videogrid.php';
	require 'includes/classes/video.php';
	require 'includes/classes/videoplayer.php';	
	require 'includes/classes/videoinfosection.php';	
	require 'includes/classes/videoinfocontrols.php';	
	require 'includes/classes/commentsection.php';	
	require 'includes/classes/comment.php';

	//session_destroy();

	if (!isset($_GET["id"])) {
		echo "No URL has sent to this page";
		exit();
	}

	$videoobj = new video($con, $_GET['id'], $userloggedinobj);
	$videoobj->incrementview();
	?>

	<div class="watchleftcolumn">
		<?php 
			$videoplayer = new videoplayer($videoobj);
			echo $videoplayer->createvideoplayer(false);

			$uploadedby = $videoobj->getuploadedby();

			$videoinfo = new videoinfosection($con, $videoobj, $userloggedin);
			echo $videoinfo->createinfosection($uploadedby);

			$commentsection = new commentsection($con, $videoobj, $userloggedin);
			echo $commentsection->create();
			

			?>
	</div>
</div>
	<div class="suggesions">
		<?php 

			$videogrid = new videogrid($con , $_GET['id']);
			echo $videogrid->create("Up Next", "no", $videoobj);
		 ?>
	</div>
	<div id="clear"></div>
























</body>
</html>