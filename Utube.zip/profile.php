<?php 
	if (isset($_GET['username'])) {
		$profileUsername = $_GET['username'];
	}
	else{
		$profileUsername = '';
		echo "No Channel Found";
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Profile || <?php echo $profileUsername; ?></title>
</head>
<body>
		<?php 
			require_once "includes/header.php";
			require_once "includes/classes/buttonprovider.php";
			echo "<div style='margin-top: 70px;'></div>";
			if (isset($_GET['username'])) {
				$query = $con->prepare("SELECT id from users where username = :username");
				$profileUsername = strtolower($profileUsername);
				$query->bindParam(":username", $profileUsername);
				$query->execute();

				if (!$query->rowCount()) {
					echo "No User Found";
					exit();
				}
			}


			$profileUserObj = new user($con, $profileUsername);
			$fullname = $profileUserObj->getfullname();
			$subscriberCount = $profileUserObj->getsubscribercount($profileUsername);
			echo "<div class='cover-photo'>
					<span class='fullname'>$fullname</span>
				</div>";

			$channelSrc = $profileUserObj->getprofilepic();
			$actionbutton = buttonprovider::createsubscribebutton($con, $profileUserObj, $profileUsername, $userloggedin);
			$profileUsername = ucfirst($profileUsername);

			if ($userloggedin == $profileUserObj->getusername()) {
				$actionImage = "changeProfilePic(this)";
				$hoverText = "Change Profile Picture";
			}
			else{
				$hoverText = $profileUsername;
				$actionImage = "";
			}

			echo "<div class='channel-info'  method='post'>
					<form id='upload-form' enctype='multipart/from-data'>
						<input type='file' name='profilePic' id='uploadImage' style='display:none'>
						<img src='$channelSrc' id='profileimage' title='$hoverText' onclick='$actionImage'>$profileUsername
						<input type='submit' name='formSubmit' id='form-submit' style='display:none'>
					</form>
						<span class='profile-subscribe'>$actionbutton</span>
					</div>";
			$profileUsername = strtolower($profileUsername);

		 ?>

	<div class="tab-container">
		<ul class="nav nav-tabs" id="myTab" role="tablist">
		  <li class="nav-item">
		    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#video" role="tab" aria-controls="home" aria-selected="true">Video</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#about" role="tab" aria-controls="profile" aria-selected="false">About</a>
		  </li>
		</ul>

		<div class="tab-content" id="myTabContent">
		  <div class="tab-pane fade show active" id="video" role="tabpanel" aria-labelledby="home-tab">
		  	 <?php 
				require_once 'includes/classes/homeVideoProvider.php';

				$homeVideo = new HomeVideo($con, $profileUsername);
				echo $homeVideo ->createHomeVideo();

			 ?>
		  </div>
		  <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="profile-tab">
		  	<?php 
		  		echo $homeVideo->createAboutSection($profileUserObj, $subscriberCount);
		  		
		  	 ?>
		  </div>
		</div>
	</div>
<script>
	$("#upload-form").on('submit', function(e){
		e.preventDefault();
		$.ajax({
		    	url: "includes/ajax/profilepic.php",
				type: "POST",
				data:  new FormData(this),
				contentType: false,
			    cache: false,
				processData:false,
				success: function(data)
			    {
			    	//JSON.parse(data);
					if (data.length > 5) {
						alert(data);
					}
					else{
						location.reload(true);
					}
			    }	        
		   });
	});
	function changeProfilePic(btn) {
		console.log('hello');
		$("#uploadImage").trigger('click');
		$("#uploadImage").change(function(){
			$("#form-submit").trigger('click');
			var htmlelement  = $("#upload-form");
				
		
		});
		
	}
			/*$.post("includes/ajax/profilepic.php", {file : myFile}).done(function(data){
				alert(data);
			});*/

	
</script>


	




</body>
</html>

