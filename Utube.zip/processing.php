<title>Video Processing</title>

<?php 
	require 'includes/header.php';
	require 'includes/classes/videouploaddata.php';
	require 'includes/classes/videoprocessor.php';
	if (!isset($_POST["submit"])) {
		echo "No data has sent to this page";
		exit();
	}

	$title = $_POST["title"];
	$title = strip_tags($title); // strip html tags
	$title = str_replace("  ", "", $title);
	$title = ucfirst($title);


	$description = $_POST["description"];
	$description = strip_tags($description); // strip html tags
	$description = str_replace("  ", "", $description);
	$description = ucfirst($description);

	$videouploaddata =  new videouploaddata($_FILES["fileinput"], $title, $description, $_POST["privacyinput"], $_POST["category"], $userloggedinobj->getusername());

	// process the data to upload
	$videoprocess = new videoprocessor($con);
	$insertedId = $videoprocess->upload($videouploaddata);
	if ($insertedId){
		$loaction = 'Location:editvideo.php?videoid='.$insertedId;
		header($loaction);
	}
	else{
		echo "Something went wrong";
		exit();
	}

 ?>