<!DOCTYPE html>
<html>
<head>
	<title>Upload Video</title>
</head>
<body>

</body>
</html>
<?php 
	require 'includes/header.php'; 
	if (!$userloggedin) {
		header("Location:signin.php");
	}
	require 'includes/classes/videodetailsfromprovider.php';
?>
<div class="column">
	<br>
	<?php 
		$formprovider = new videodetailsfromprovider($con);
		echo $formprovider->createfromprovider();
	 ?>
	 <script>
	 	$("form").submit(function(){
	 		$("#loadingmodal").modal("show");
	 	});
	 </script>
	 <!-- loading modal  -->
	<div class="modal" tabindex="-1" id="loadingmodal" role="dialog" data-backdrop="static" data-keyboard="false">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title">Data processing</h5>
	      </div>
	      <div class="modal-body">
	        <p>
		        Please wait, don't press any key &nbsp &nbsp &nbsp
		        <img src="includes/images/loading.gif" width="50" height="50">
	        </p>
	      </div>
	    </div>
	  </div>
	</div>


</div>