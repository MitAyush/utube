<!DOCTYPE html>
<html>
<head>
	<title>Search || Video</title>
</head>
<body>

	<?php 
		require_once "includes/header.php";
		
		if (isset($_GET['search'])) {

			echo "<div style='margin-top: 70px;'></div>";
			require_once "includes/classes/search.php";
			$searchResult = new Search($con);
			echo $searchResult->getResult();
		}
		else{
			echo "Nothing was searched";
		}

	 ?>
</body>
</html>