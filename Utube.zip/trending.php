<title>Trending</title>
<?php 
	require_once "includes/header.php";
	require_once "includes/classes/trendingProvider.php";

	

 ?>
<div class="mainsection">
		<div class="maincontent">
			<?php 
				$trendingVideos = new TrendingPrpvider($con);
				echo $trendingVideos->getTrendingVideo();
			 ?>
		</div>
</div>