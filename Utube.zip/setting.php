<title>Settings</title>
<?php 
	require 'includes/header.php';
	if (!isset($_SESSION['userloggedin'])) {
		header("Location:signin.php");
	}

	$firstname = $userloggedinobj->getfirstname();
	$lastname = $userloggedinobj->getlastname();
	$email = $userloggedinobj->getemail();
	$username = $_SESSION['userloggedin'];
	$aboutText = $userloggedinobj->getabout();

	require 'includes/classes/validation.php';
	require 'includes/classes/formsantizer.php';
	$formsantizer = new formsantizer();

	if (isset($_POST['update'])) {
		

		$firstname = $formsantizer->srtingsantinize($_POST["firstname"], 1);
		$lastname = $formsantizer->srtingsantinize($_POST["lastname"], 1);
		$email = $formsantizer->srtingsantinize($_POST["email"], 0);
		

	}
	elseif (isset($_POST['setpassword'])) {
		$password = $formsantizer->passwordsantinize($_POST["password"]);
		$oldpassword = $formsantizer->passwordsantinize($_POST["oldPassword"]);

		$oldpassword = hash('md5', $oldpassword);
		$oldpassword = hash('md5', $oldpassword);

		$oldpassword .="vko5m5m5m5skls";
	}
	elseif (isset($_POST['about'])) {
		$aboutText = strip_tags($_POST['about-text']);
		$aboutText = str_replace("  ", "", $aboutText);

		$query = $con->prepare("UPDATE users set about = :aboutText where username = :username");
		$query->bindParam(":aboutText", $aboutText);
		$query->bindParam(":username", $userloggedin);
		$query->execute();
	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Setting</title>
</head>
<body>
<div class="signup-login">
	
<!-- -------------------------- Setting form --------------------------->
<br>
<br>
	<div class="login">
		<div class="row justify-content-center">
		<div class="col-md-6">
			<div class="card">
			<header class="card-header">
				<h4 class="card-title mt-2">Settings</h4>
			</header>
			<article class="card-body">
			<form action="" method="POST">
				<div class="form-row">
				<div class="col form-group">
					<label for="firstname">First name </label>   
				  	<input type="text" class="form-control" value="<?php echo $firstname; ?>" name="firstname" id="firstname" placeholder="" autocomplete="off" required>
				  	<small class="form-text fncls hideit" style="color:red;">First name must be between 3 and 15.</small>
				</div> <!-- form-group end.// -->
				<div class="col form-group">
					<label for="lastname">Last name</label>
				  	<input type="text" class="form-control" value="<?php echo $lastname; ?>" id="lastname" name="lastname" placeholder="" autocomplete="off" required>
				  	<small class="form-text lncls hideit" style="color:red;">Last name must be between 3 and 15.</small>
				</div> <!-- form-group end.// -->
			</div> <!-- form-row end.// -->
			<div class="form-group">
				<label for="email">Email address</label>
				<input type="email" class="form-control" value="" name="email" id="email" autocomplete="off" >
				<small class="form-text emcls hideit" style="color:red;">Email address is not valid.</small>
				<small class="form-text emtaken hideit" style="color:red;">Email address has already taken.</small>
			</div>
			<div class="form-group">
		        <button type="submit" name="update" class="btn btn-primary btn-block"> Save </button>
		    </div>     
			                                             
			</form>

			<form action="" method="POST">
				<div class="form-group">
					<label for="oldPassword">Old password</label>
					<input type="password" class="form-control" value="" name="oldPassword" id="oldPassword" placeholder="**********" required>
					<small class="form-text old-pwd hideit" style="color:red;">Old Password is incorrect.</small>
				</div> <!-- form-group end.// -->
				
				<div class="form-group">
					<label for="newPasword">New password</label>
				    <input class="form-control" type="password" name="password" id="newPasword" required>
				    <small class="form-text  pwd hideit" style="color:red;">Password must be between 8 and 25.</small>
				</div>
				<div class="form-group">
			        <button type="submit" name="setpassword" class="btn btn-primary btn-block"> Save </button>
			    </div>
			</form>

			<form action="" method="POST">
				<div class="form-group">
					<label for="oldPassword">About</label>
					<textarea class="form-control" name="about-text"><?php 	echo $aboutText; ?></textarea>
					<small class="form-text hideit" style="color:red;">About error.</small>
				</div>

				<div class="form-group">
			        <button type="submit" name="about" class="btn btn-primary btn-block"> Save </button>
			    </div>
			</form>
				
				 <!-- form-group end.// -->  
			    </article> <!-- card-body end .// -->
			</div> <!-- card.// -->
		</div> <!-- col.//-->

		</div>
	</div>
</div>

</body>
</html>
<?php 
	if (isset($_POST['update'])) {

		/*===================================validation========================*/
		$validate = new validation();
		$isvalidfirstname = $validate->validatefirstname($firstname);
		if (!$isvalidfirstname) {
			echo "<script>
				$('.fncls').removeClass('hideit');
			</script>";	
		}		

		$isvalidlastname = $validate->validatelastname($lastname);
		if (!$isvalidlastname) {
			echo "<script>
				$('.lncls').removeClass('hideit');
			</script>";	
		}

		if (sizeof($email) > 0) {
			$isvalidemail = $validate->validateemail($email);
			if (!$isvalidemail) {
				echo "<script>
					$('.uncls').removeClass('hideit');
				</script>";	
			}
			$emailtaken = $validate->emailtaken($email, $con);
			if ($emailtaken) {
				echo "<script>
					$('.emtaken').removeClass('hideit');
				</script>";	
			}

		}
		else{
			$isvalidemail = false;
			$emailtaken = false;
			$email = true;
		}

		/*============= Update the data=====================*/

		if ($isvalidlastname && $isvalidfirstname) {

			if ((!$emailtaken) && $isvalidemail) {
				$query = $con->prepare("UPDATE users set firstname = :firstname, lastname = :lastname, email = :email
									where username = :username");
				$profilepic = 'includes/images/profilepic/default.jpg';
				
				$query->bindParam(":firstname", $firstname);
				$query->bindParam(":lastname", $lastname);
				$query->bindParam(":email", $email);
				$query->bindParam(":username", $username);
				$query->execute();
				echo "<script>alert('Email Updated')</script>";
			}
			else{
				$query = $con->prepare("UPDATE users set firstname = :firstname, lastname = :lastname 
										where username = :username");
				$query->bindParam(":firstname", $firstname);
				$query->bindParam(":lastname", $lastname);
				$query->bindParam(":username", $username);
				$query->execute();
				echo "<script>alert('First and Last name updated')</script>";
			}
			
			
		}	
	}
	elseif (isset($_POST['setpassword'])) {
		$validate = new validation();
		$isvalidpassword = $validate->validatepassword($password);
		if (!$isvalidpassword) {
			echo "<script>
				$('.pwd').removeClass('hideit');
			</script>";	
		}

		$isvalidoldpassword = $validate->validateOldPassword($oldpassword, $con, $username);
		if (!$isvalidoldpassword) {
			echo "<script>
				$('.old-pwd').removeClass('hideit');
			</script>";	
		}
		$password = hash('md5', $password);
		$password = hash('md5', $password);

		$password .= "vko5m5m5m5skls";
		/*============= Update the passeord =====================*/

		if ($isvalidoldpassword && $isvalidpassword) {
			
			$query = $con->prepare("UPDATE users set password = :password where username = :username");
			$profilepic = 'includes/images/profilepic/default.jpg';
			
			$query->bindParam(":password", $password);
			$query->bindParam(":username", $username);
			if($query->execute()){
				echo "<script>alert('done password')</script>";
			}
			else{
				echo "<script>alert('update fail')</script>";
				return false;
			}
		}
	}
	

 ?>