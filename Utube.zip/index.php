<!DOCTYPE html>
<html>
<head>
	<title>Utube</title>
</head>
<style>
</style>
<body>
	<?php 
		
		require 'includes/header.php';
		require_once 'includes/classes/subscription.php';
		require_once 'includes/classes/recommended.php';

	 ?>
	<div class="mainsection">
		<div class="maincontent">
			<?php 

				$userToArray = $userloggedinobj->getSubscribtionTo();
	
				$subscriptionVideo = new subscription($con, $userToArray);
				$subscriptionData = $subscriptionVideo->subscriptionVideos();
				if (is_null($subscriptionData)) {
					echo "<h5 class='sub-title' style='padding-top: 50px;'>RECOMMENDED</h5>";
				}
				else{
					echo $subscriptionData;
				}

				$recommended = new recommended($con, $userToArray);
				echo $recommended->recommendedVideo();

			 ?>
		</div>
	</div>
</body>
</html>